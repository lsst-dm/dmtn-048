#! /usr/local/bin/bash
#
# ------------------------------------------------
# Sets up for x-match and update tests
#
# 1,2    The minimum,maximum dec of objects to load
# 3,4    The minimum,maximum ra of objects to load
# ------------------------------------------------
setupForWrites()
{
    SQL="DROP TABLE IF EXISTS InMemoryDIASource;
         CREATE TABLE InMemoryDIASource LIKE DIASource;
         ALTER TABLE InMemoryDIASource ENGINE = MEMORY;
         ALTER TABLE InMemoryDIASource CHANGE COLUMN id id BIGINT NOT NULL;
         ALTER TABLE InMemoryDIASource DROP INDEX idx_spatial;
         ALTER TABLE InMemoryDIASource ADD INDEX idx_zone_ra USING BTREE (zoneId,ra);
         DROP TABLE IF EXISTS LooseMatch;
         CREATE TABLE IF NOT EXISTS LooseMatch (
                  id1 bigint not null,
                  id2 bigint not null) ENGINE = MEMORY;
         DROP TABLE IF EXISTS WideLooseMatch;
         CREATE TABLE WideLooseMatch LIKE InMemoryFineChunkTemplate;
         ALTER TABLE WideLooseMatch DROP PRIMARY KEY;
         ALTER TABLE WideLooseMatch DROP INDEX idx_zone;
         ALTER TABLE WideLooseMatch ADD COLUMN isDirty BOOL NOT NULL;
         ALTER TABLE WideLooseMatch ADD COLUMN diaSourceId BIGINT NOT NULL;
         DROP TABLE IF EXISTS WideFatLooseMatch;
         CREATE TABLE WideFatLooseMatch LIKE InMemoryFineFatChunkTemplate;
         ALTER TABLE WideFatLooseMatch DROP PRIMARY KEY;
         ALTER TABLE WideFatLooseMatch DROP INDEX idx_zone;
         ALTER TABLE WideFatLooseMatch ADD COLUMN isDirty BOOL NOT NULL;
         ALTER TABLE WideFatLooseMatch ADD COLUMN diaSourceId BIGINT NOT NULL;
         TRUNCATE TABLE MemChunks;
         INSERT INTO MemChunks SELECT * FROM ObjectFineChunks;"

    mysql $TEST_DB -e "$SQL" >> $LOGFILE 2>&1
    
    cmp=$(echo "if($3 > $4) 1" | bc)
    if [[ $cmp -eq 1 ]]
    then
        WHERE_CLAUSE="((ra >= $3) or (ra < $4))"
    else
        WHERE_CLAUSE="ra >= $3 and ra < $4"
    fi
    WHERE_CLAUSE="WHERE decl >= $1 and decl < $2 and $WHERE_CLAUSE"

    SQL="INSERT INTO InMemoryDIASource SELECT * FROM DIASource $WHERE_CLAUSE;"
    (time mysql $TEST_DB -e "$SQL") >> $LOGFILE 2>&1
    
    (time mysql $TEST_DB -e "CALL sp_populateZoneZone(8.33e-4);") >> $LOGFILE 2>&1
}

# ------------------------------------------------
# Performs a loose cross-match: (diaSourceId,objectId) pair version
# ------------------------------------------------
xmatchOrig()
{
    echo "x-match, obj to dia:" >> $LOGFILE
    mysql $TEST_DB -e "TRUNCATE TABLE LooseMatch;"
    mpstat $MPSTAT_PARMS >> $LOGFILE &
    MPSTAT_PID="$(jobs -p %%)"
    (time mysql $TEST_DB -e "CALL sp_crossMatchOrig('InMemoryObject', 'InMemoryDIASource', 'LooseMatch', 0.000833, 0);") >> $LOGFILE 2>&1
    kill $MPSTAT_PID
    
    echo "x-match, dia to obj:" >> $LOGFILE
    mysql $TEST_DB -e "TRUNCATE TABLE LooseMatch;"
    mpstat $MPSTAT_PARMS >> $LOGFILE &
    MPSTAT_PID="$(jobs -p %%)"
    (time mysql $TEST_DB -e "CALL sp_crossMatchOrig('InMemoryDIASource', 'InMemoryObject', 'LooseMatch', 0.000833, 0);") >> $LOGFILE 2>&1
    kill $MPSTAT_PID
}

xmatch()
{
    echo "x-match, obj to dia:" >> $LOGFILE
    mysql $TEST_DB -e "TRUNCATE TABLE LooseMatch;"
    mpstat $MPSTAT_PARMS >> $LOGFILE &
    MPSTAT_PID="$(jobs -p %%)"
    (time mysql $TEST_DB -e "CALL sp_crossMatch('InMemoryObject', 'InMemoryDIASource', 'LooseMatch', 0.000833, 0, 0, 360, 0);") >> $LOGFILE 2>&1
    kill $MPSTAT_PID

    echo "x-match, dia to obj:" >> $LOGFILE
    mysql $TEST_DB -e "TRUNCATE TABLE LooseMatch;"
    mpstat $MPSTAT_PARMS >> $LOGFILE &
    MPSTAT_PID="$(jobs -p %%)"
    (time mysql $TEST_DB -e "CALL sp_crossMatch('InMemoryDIASource', 'InMemoryObject', 'LooseMatch', 0.000833, 0, 0, 360, 0);") >> $LOGFILE 2>&1
    kill $MPSTAT_PID
}


# ------------------------------------------------
# Performs a loose cross-match: (Object,diaSourceId) pair version
#
# 1      The name of the table to store matches in
# ------------------------------------------------
wxmatchOrig()
{
    echo "wide x-match, obj to dia:" >> $LOGFILE
    mysql $TEST_DB -e "TRUNCATE TABLE $1;"
    mpstat $MPSTAT_PARMS >> $LOGFILE &
    MPSTAT_PID="$(jobs -p %%)"
    (time mysql $TEST_DB -e "CALL sp_crossMatchOrig('InMemoryObject', 'InMemoryDIASource', '$1', 0.000833, 1);") >> $LOGFILE 2>&1
    kill $MPSTAT_PID

    echo "wide x-match, dia to obj:" >> $LOGFILE
    mysql $TEST_DB -e "TRUNCATE TABLE $1;"
    mpstat $MPSTAT_PARMS >> $LOGFILE &
    MPSTAT_PID="$(jobs -p %%)"
    (time mysql $TEST_DB -e "CALL sp_crossMatchOrig('InMemoryDIASource', 'InMemoryObject', '$1', 0.000833, -1);") >> $LOGFILE 2>&1
    kill $MPSTAT_PID
}

wxmatch()
{
    echo "wide x-match, obj to dia:" >> $LOGFILE
    mysql $TEST_DB -e "TRUNCATE TABLE $1;"
    mpstat $MPSTAT_PARMS >> $LOGFILE &
    MPSTAT_PID="$(jobs -p %%)"
    (time mysql $TEST_DB -e "CALL sp_crossMatch('InMemoryObject', 'InMemoryDIASource', '$1', 0.000833, 1, 0, 360, 0);") >> $LOGFILE 2>&1
    kill $MPSTAT_PID

    echo "wide x-match, dia to obj:" >> $LOGFILE
    mysql $TEST_DB -e "TRUNCATE TABLE $1;"
    mpstat $MPSTAT_PARMS >> $LOGFILE &
    MPSTAT_PID="$(jobs -p %%)"
    (time mysql $TEST_DB -e "CALL sp_crossMatch('InMemoryDIASource', 'InMemoryObject', '$1', 0.000833, -1, 0, 360, 0);") >> $LOGFILE 2>&1
    kill $MPSTAT_PID
}
