/* ================================================================
    
    Stored procedures that implement the loose cross-match stage
    of the association pipeline.
    
    WARNING: this implementation is NOT entirely complete - in particular,
    the implementation of the standard zone algorithm does not deal with ra
    wrap around (since none of the test regions are close to ra =0,360). Also,
    the match radius is assumed to be less than or equal to the zone height,
    which is currently 1 arc-minute. For actual LSST data I would expect much
    smaller zone height (say 5, 10, 15 arcseconds or there-abouts). Also, since
    these routines are focused on the base camp, we don't need to support a
    general match radius.
    
    To really understand what's going on here read the following paper
    for a detailed explanation of the algorithm/approach:
    
    MSR-TR-2006-52
    The Zones Algorithm for Finding Points-Near-a-Point or 
    Cross-Matching Spatial Datasets
    Gray, Jim; Nieto-Santisteban, Maria A.; Szalay, Alexander S.
    April 2006
    http://research.microsoft.com/research/pubs/view.aspx?msr_tr_id=MSR-TR-2006-52
    
  ================================================================ */

drop function  if exists sf_deltaRa;
drop procedure if exists sp_populateZoneZone;
drop procedure if exists sp_crossMatchOrig;
drop procedure if exists sp_crossMatch;
drop procedure if exists sp_rows;
drop procedure if exists sp_crossMatchChunk;
drop procedure if exists sp_crossMatchChunks;
drop procedure if exists sp_crossMatchStripe;

delimiter //


/* ----------------------------------------------------------------
    Computes required ra search width from the match radius theta,
    given in degrees, and the declination decl, also specified in
    degrees.
   ---------------------------------------------------------------- */
create function sf_deltaRa(_theta double precision,
                           _decl  double precision)
    returns double precision
    deterministic
    comment 'Computes ra search width for match-radius theta at a given declination decl'
begin
    declare _x double precision;
    declare _y double precision;
    if abs(_decl) + _theta > 89.9 then 
        return 180.0;
    end if;
    set _y = sin(radians(_theta));
    set _x = sqrt(abs(cos(radians(_decl - _theta)) * cos(radians(_decl + _theta))));
    return degrees(abs(atan(_y / _x)));
end;
//
/* ---------------------------------------------------------------- */


/* ----------------------------------------------------------------
    Populates the ZoneZone table with zones, each 1 arc-minute
    high (there are 10800 in total). If the match radius theta
    is larger than this, ZoneZone is truncated and left empty.

    WARNING: assumes _theta is less than or equal to 1 arc-minute.
   ---------------------------------------------------------------- */
create procedure sp_populateZoneZone(_theta double precision)
    modifies sql data
    comment 'Populates ZoneZone table (maps zones to zones with potential matches)'
begin
    declare _zone    int;
    declare _deltaRa double precision;
    declare _z       double precision;
    
    truncate table ZoneZone;
    if _theta <= 1/60.0 then
        insert into ZoneZone values
            (-5400, -5400, 180.0),
            (-5400, -5399, 180.0);
        set _zone = -5399;
        while _zone < 5399 do
            set _z = _zone;
            set _deltaRa = case when _z < 0.0 then sf_deltaRa(_theta, _z/60.0)
                                else sf_deltaRa(_theta, (_z + 1.0)/60.0) end;
            insert into ZoneZone values
                (_zone, _zone - 1, _deltaRa),
                (_zone, _zone,     _deltaRa),
                (_zone, _zone + 1, _deltaRa);
            set _zone = _zone + 1;
        end while;
        insert into ZoneZone values
            (5399, 5398, 180.0),
            (5399, 5399, 180.0);
    end if;
end;
//
/* ---------------------------------------------------------------- */


/* ----------------------------------------------------------------
    Computes a radius _theta cross match between the given primary
    and secondary tables, storing the results in the specified result
    table.

    WARNING: ra wrap-around is NOT dealt with,
             _theta is assumed to be <= 1 arcminute
        
    Notes:
    
    - distance/position angle of the match are not computed since it's
      cheap to do so later (we have many compute nodes but a centralized
      DBMS server, so save CPU time on DBMS server)
    
    - _mode controls the results of the cross-match:
         0      primary id, secondary id pair
        <0      all columns in secondary table, primary id
        >0      all columns in primary table, secondary id
    
    - I cannot get MySQL to run the query below efficiently, even if
      I supply index hints. Using EXPLAIN on the select statement involved
      indicates all relevant indexes are being used anyway, so as far as
      I can tell the query plan is as follows:
    
      for each position in the primary table:
         - get zones containing possible matches from ZoneZone (using PK).
         for each zone containing possible matches:
            - get positions in the secondary table that belong to the 
              possibly matching zone (using idx_zone_ra)
            - compare these positions to the primary position
    
      So, idx_zone_ra is used to get positions from the secondary
      table that are in potentially matching zones, but not to
      further restrict positions to those within deltaRa of the
      primary positions ra value. The procedure takes about 35
      minutes to match 30k DIASources to 3 million Objects (dual
      Sun UltraSPARC IIIi at 1.5GHz, all tables involved in memory)
      which is terrible.
    
      Moving the ra range test to the 'on' clause of the join doesn't help:
    
      insert into matchTable
          select p.id, s.id from primaryTable as p
          inner join ZoneZone as zz on p.zoneId = zz.zoneId
          inner join secondaryTable as s on 
              zz.matchZoneId = s.zoneId and 
              s.ra between p.ra - zz.deltaRa and p.ra + zz.deltaRa
          where s.decl between p.decl - theta and p.decl + theta
          and pow(p.x - s.x, 2) + pow(p.y - s.y, 2) + pow(p.z - s.z, 2) < dmax
    
      I leave the implementation here in case someone can figure out a way to
      make it work. See sp_crossMatch for a more involved implementation
      that takes about 33 seconds on the same inputs.
   ---------------------------------------------------------------- */
create procedure sp_crossMatchOrig(_primaryTable   varchar(255), 
                                   _secondaryTable varchar(255),
                                   _matchTable     varchar(255),
                                   _theta          double precision,
                                   _mode           int)
    modifies sql data
    comment 'performs a radius theta cross-match between two tables'
begin
    declare _dmax double precision;
    declare _cols varchar(32);

    set _dmax = 4*pow(sin(radians(_theta/2)), 2);
    set _cols = case when _mode < 0 then 's.*,  p.id'
                     when _mode = 0 then 'p.id, s.id'
                     else                'p.*,  s.id' end;
    set @sql_str = concat('insert into ', _matchTable, 
        ' select ', _cols, ' from ', _primaryTable, ' as p ',
        ' inner join ZoneZone as zz on p.zoneId = zz.zoneId ',
        ' inner join ', _secondaryTable, ' as s on zz.matchZoneId = s.zoneId ',
        ' where s.ra between p.ra - zz.deltaRa and p.ra + zz.deltaRa ',
        ' and s.decl between p.decl - ', _theta, ' and p.decl + ', _theta, 
        ' and pow(p.x - s.x, 2) + pow(p.y - s.y, 2) + pow(p.z - s.z, 2) < ',
        _dmax);
    prepare sql_stmt from @sql_str;
    execute sql_stmt;
    deallocate prepare sql_stmt;

end;
//
/* ---------------------------------------------------------------- */


/* ----------------------------------------------------------------
    Counts the number of rows in the given table, returning 0
    if the table doesn't exist.
    
    This is a hack but is many many times faster than consulting
    'information_schema.tables'.
   ---------------------------------------------------------------- */
create procedure sp_rows(_tableName varchar(255))
    comment 'counts the number of rows in the given table'
begin
    declare exit handler for 1146 set @rows = 0; -- SQLSTATE '42S02' (table doesn't exist)

    set @sql_str = concat('select count(*) from ', _tableName, ' into @rows');
    -- if _tableName doesn't exist, the prepare will fail
    prepare count_stmt from @sql_str;
    execute count_stmt;
    deallocate prepare count_stmt;
end;
//
/* ---------------------------------------------------------------- */

/* ----------------------------------------------------------------
    Faster version of cross matching routine (which also correctly
    handles ra wrap around).

    WARNING: assumes _theta is <= 1 arcminute.

    - _mode controls the results of the cross-match:
         0      primary id, secondary id pair
        <0      all columns in secondary table, primary id
        >0      all columns in primary table, secondary id
    
    - _raMin, _raMax are the ra bounds of the primary table, and
      must be in range [0, 360]
    
    - _margin is the margin in ra around the primary table that
      must be searched for matches
    
    If you don't want to think too hard about these parameters, pass
    (_raMin, _raMax) = (0, 360) and _margin = 180 (or _margin = 0
    if you know wrap-around won't occur). Passing a margin of 180 degrees
    has a large performance impact though (2-3x slowdown) so being
    careful is worth it.
           
   ---------------------------------------------------------------- */
create procedure sp_crossMatch(_primaryTable   varchar(255), 
                               _secondaryTable varchar(255),
                               _matchTable     varchar(255),
                               _theta          double precision,
                               _mode           int,
                               _raMin          double precision,
                               _raMax          double precision,
                               _margin         double precision)
    modifies sql data
    comment 'performs a radius theta cross-match between two tables'
begin
    declare _dmax  double precision;
    declare _z     double precision;
    declare _n     int;

    -- Get the minimum and maximum zoneId in the primary table
    set @sql_str = concat('select min(zoneId), max(zoneId) from ', 
        _primaryTable, ' into @minZone, @maxZone');
    prepare sql_stmt from @sql_str;
    execute sql_stmt;
    deallocate prepare sql_stmt;

    -- Create temporary secondary zone table
    create temporary table if not exists SecondaryZone like SecondaryZoneTemplate;
    truncate table SecondaryZone;

    -- Initialize secondary zone table with data from @minZone and the
    -- 2 sandwiching zones. SecondaryZone will be maintained such
    -- that it always contains data for zones in the neighbourhood of
    -- the primary zone.
    set @sql_str = concat('insert into SecondaryZone select ra,decl,x,y,z,id,zoneId from ',
        _secondaryTable, ' where zoneId between ', @minZone - 1, ' and ', @minZone + 1,
        ' and ra between ', _raMin - _margin, ' and ', _raMax + _margin);
    if _raMin < _margin then
        set @sql_str = concat(@sql_str, ' union select ra - 360,decl,x,y,z,id,zoneId from ',
            _secondaryTable, ' where zoneId between ', @minZone - 1, ' and ', @minZone + 1,
            ' and ra >= ', _raMin - _margin + 360);
    end if;
    if _raMax > 360 - _margin then
        set @sql_str = concat(@sql_str, ' union select ra + 360,decl,x,y,z,id,zoneId from ',
            _secondaryTable, ' where zoneId between ', @minZone - 1, ' and ', @minZone + 1,
            ' and ra <= ', _raMax + _margin - 360);
    end if;
    prepare sinit_stmt from @sql_str;
    execute sinit_stmt;
    deallocate prepare sinit_stmt;

    -- Prepare the x-match statement
    set _dmax = 4*pow(sin(radians(_theta/2)), 2);
    if _mode < 0 then
        set @sql_str = concat('insert into ', _matchTable,
            ' select t.*, p.id from ', _primaryTable, ' as p ',
            ' inner join SecondaryZone as s on s.ra between p.ra - ? and p.ra + ? ',
            ' inner join ', _secondaryTable, ' as t on t.id = s.id ',
            ' where p.zoneId = ? ',
            ' and s.decl between p.decl - ', _theta, ' and p.decl + ', _theta, 
            ' and pow(p.x - s.x, 2) + pow(p.y - s.y, 2) + pow(p.z - s.z, 2) < ', _dmax);
    elseif _mode = 0 then
        set @sql_str = concat('insert into ', _matchTable,
            ' select p.id, s.id from ', _primaryTable, ' as p ',
            ' inner join SecondaryZone as s on s.ra between p.ra - ? and p.ra + ? ',
            ' where p.zoneId = ? ',
            ' and s.decl between p.decl - ', _theta, ' and p.decl + ', _theta, 
            ' and pow(p.x - s.x, 2) + pow(p.y - s.y, 2) + pow(p.z - s.z, 2) < ', _dmax);
    else -- _mode > 0
        set @sql_str = concat('insert into ', _matchTable,
            ' select p.*, s.id from ', _primaryTable, ' as p ',
            ' inner join SecondaryZone as s on s.ra between p.ra - ? and p.ra + ? ',
            ' where p.zoneId = ? ',
            ' and s.decl between p.decl - ', _theta, ' and p.decl + ', _theta, 
            ' and pow(p.x - s.x, 2) + pow(p.y - s.y, 2) + pow(p.z - s.z, 2) < ', _dmax);
    end if;
    prepare xmatch_stmt from @sql_str;

    -- Prepare the SecondaryZone insert statement
    set @sql_str = concat('insert into SecondaryZone select ra,decl,x,y,z,id,zoneId from ',
         _secondaryTable, ' where zoneId = ? and ra between ', _raMin - _margin, 
         ' and ', _raMax + _margin);
    set _n = 1;
    if _raMin < _margin then
        set @sql_str = concat(@sql_str, ' union select ra - 360,decl,x,y,z,id,zoneId from ',
            _secondaryTable, ' where zoneId = ? and ra >= ', _raMin - _margin + 360);
        set _n = _n + 1;
    end if;
    if _raMax > 360 - _margin then
        set @sql_str = concat(@sql_str, ' union select ra + 360,decl,x,y,z,id,zoneId from ',
            _secondaryTable, ' where zoneId = ? and ra <= ', _raMax + _margin - 360);
        set _n = _n + 1;
    end if;
    prepare sins_stmt from @sql_str;

    -- Prepare the SecondaryZone delete statement
    prepare sdel_stmt from 'delete from SecondaryZone where zoneId = ?';

    -- Loop over all zones in the primary table:
    while @minZone <= @maxZone do
        set _z = @minZone;
        set @dra = case when _z < 0.0 then sf_deltaRa(_theta, _z/60.0)
                        else sf_deltaRa(_theta, (_z + 1.0)/60.0) end;
        -- match against the contents of SecondaryZone
        execute xmatch_stmt using @dra, @dra, @minZone;
        set @zone = @minZone - 1;
        -- pop the smallest zone from SecondaryZone
        execute sdel_stmt using @zone;
        -- push new zone to SecondaryZone (3-zone sliding window)
        set @zone = @minZone + 2;
        case _n
            when 3 then execute sins_stmt using @zone, @zone, @zone;
            when 2 then execute sins_stmt using @zone, @zone;
            when 1 then execute sins_stmt using @zone;
        end case;
        -- advance to the next primary zone and repeat.
        set @minZone = @minZone + 1;
    end while;

    -- free up memory and clean up
    truncate table SecondaryZone;
    deallocate prepare sdel_stmt;
    deallocate prepare sins_stmt;
    deallocate prepare xmatch_stmt;

end;
//
/* ---------------------------------------------------------------- */

  
/* ----------------------------------------------------------------
   Given the id of a chunk, finds neighbouring chunks and performs an 
   x-match of the primary chunk versus all neighbours.
   
   WARNING: assumes _theta is <= 1 arcminute.

   Notes:
   
   - secondary chunk table names are constructed by appending a
     chunk id to _secondaryPrefix.
     
   - _mode controls the results of the cross-match:
        0      primary id, secondary id pair
       <0      all columns in secondary table, primary id
       >0      all columns in primary table, secondary id
   
   - parallelization is quite simple: process primary chunks in parallel
     (matching for a given primary chunk is independent of all other chunks).
     The hope is that given an N-core database server, splitting the work
     amongst M <= N clients will give linear speedup (to be tested).

   - because chunks are already so small, it might be OK to match using
     the sp_crossMatchOrig procedure (which would have to be extended to
     deal with ra-wrap around). It may not use indexes efficiently, but
     it does all its work in one statement, so has less book-keeping
     overhead than sp_crossMatch.

   ---------------------------------------------------------------- */
create procedure sp_crossMatchChunk(_chunk           int,
                                    _primaryTable    varchar(255),
                                    _secondaryPrefix varchar(255),
                                    _matchTable      varchar(255),                                     
                                    _theta           double precision,
                                    _mode            int)
    modifies sql data
    comment 'performs a radius theta cross-match between a chunk and all potentially matching chunks'
begin
    declare _raMin          double precision;
    declare _raMax          double precision;
    declare _decMin         double precision;
    declare _decMax         double precision;
    declare _deltaRa        double precision; 
    declare _stripeMax      int;
    declare _stripe         int;
    declare _numChunks      int;
    declare _minChunk       int;
    declare _maxChunk       int;
    declare _candidate      int;
    declare _secondaryTable varchar(255);

    
    -- lookup dimensions of the chunk
    select raMin, raMax, decMin, decMax from MemChunks where chunkId = _chunk
        into _raMin, _raMax, _decMin, _decMax;
    -- find search margin in ra
    set _deltaRa = case when abs(_decMin) > abs(_decMax) then sf_deltaRa(_theta, abs(_decMin))
                        else sf_deltaRa(_theta, abs(_decMax)) end;
    
    -- find indexes of the stripe containing _chunk and the at most 2 neighbours
    set _stripe    = floor(_chunk/1028) - 259;
    set _stripeMax = _stripe + 2;
    if _stripe    < -258 then set _stripe    = -258; end if;
    if _stripeMax >  257 then set _stripeMax =  257; end if;

    -- loop over stripes sandwiching _chunk
    while _stripe <= _stripeMax do

        -- determine which chunks in _stripe could contain matches for _chunk 
        select numChunks from MemStripes where stripeId = _stripe into _numChunks;
        set _minChunk = floor(((_raMin - _deltaRa)*_numChunks) / 360);
        set _maxChunk = floor(((_raMax + _deltaRa)*_numChunks) / 360);

        -- loop over potentially matching chunks
        while _minChunk <= _maxChunk do

            -- get id of the current chunk and construct name of corresponding in-memory table
            set _candidate = (_stripe + 258)*1028 + (_minChunk % _numChunks);
            set _secondaryTable = concat(_secondaryPrefix, _candidate);
            -- check that the secondary table exists and is non empty
            call sp_rows(_secondaryTable);
            -- if so call the cross matching procedure
            if @rows > 0 then
                call sp_crossMatch(_primaryTable, _secondaryTable, _matchTable,
                                   _theta, _mode, _raMin, _raMax, _deltaRa);
            end if;
            set _minChunk = _minChunk + 1;
        end while;

        set _stripe = _stripe + 1;
    end while;

end;
//
/* ---------------------------------------------------------------- */


/* ----------------------------------------------------------------
   Equivalent to calling sp_crossMatchChunk for 
   _chunkBeg, _chunkBeg + 1, ... , _chunkEnd. 
   
   WARNING: assumes _theta is <= 1 arcminute.

   Notes:
   
   - Primary chunk table names are constructed by appending a
     chunk id to _primaryPrefix.
   
   - since there are roughly 128 chunks per FOV, but we are unlikely
     to get 128 cores any time soon, this routine handles a bunch
     of chunks at once.
   ---------------------------------------------------------------- */
create procedure sp_crossMatchChunks(_chunkBeg        int,
                                     _chunkEnd        int,
                                     _primaryPrefix   varchar(255),
                                     _secondaryPrefix varchar(255),
                                     _matchTable      varchar(255),                                     
                                     _theta           double precision,
                                     _mode            int)
    modifies sql data
    comment 'performs a radius theta cross-match between a series of consecutive chunks and all potentially matching chunks'
begin
    declare _raMin          double precision;
    declare _raMax          double precision;
    declare _decMin         double precision;
    declare _decMax         double precision;
    declare _deltaRa        double precision; 
    declare _stripe         int;
    declare _stripeBeg      int;
    declare _stripeEnd      int;
    declare _chunk          int;
    declare _numChunks      int;
    declare _minChunk       int;
    declare _maxChunk       int;
    declare _candidate      int;
    declare _primaryTable   varchar(255);
    declare _secondaryTable varchar(255);
    
    -- lookup dimensions of the chunk
    select decMin, decMax from MemChunks where chunkId = _chunkBeg into _decMin, _decMax;
    -- find search margin in ra
    set _deltaRa = case when abs(_decMin) > abs(_decMax) then sf_deltaRa(_theta, abs(_decMin))
                        else sf_deltaRa(_theta, abs(_decMax)) end;
    
    -- find indexes of the stripe containing _chunk and the at most 2 neighbours
    set _stripeBeg = floor(_chunkBeg/1028) - 259;
    set _stripeEnd = _stripeBeg + 2;
    if _stripeBeg < -258 then set _stripeBeg = -258; end if;
    if _stripeEnd >  257 then set _stripeEnd =  257; end if;

    -- loop over primary chunks
    set _chunk = _chunkBeg;
    while _chunk <= _chunkEnd do

        -- construct name of primary table
        set _primaryTable = concat(_primaryPrefix, _chunk);
        call sp_rows(_primaryTable);

        if @rows > 0 then

            select raMin, raMax from MemChunks where chunkId = _chunk into _raMin, _raMax;
            set _stripe = _stripeBeg;

            -- loop over stripes sandwiching the chunks
            while _stripe <= _stripeEnd do

                -- determine which chunks in _stripe could contain matches for _chunk 
                select numChunks from MemStripes where stripeId = _stripe into _numChunks;
                set _minChunk = floor(((_raMin - _deltaRa)*_numChunks) / 360);
                set _maxChunk = floor(((_raMax + _deltaRa)*_numChunks) / 360);

                -- loop over potentially matching chunks
                while _minChunk <= _maxChunk do
                    -- construct name of corresponding in-memory table
                    set _candidate = (_stripe + 258)*1028 + (_minChunk % _numChunks);
                    set _secondaryTable = concat(_secondaryPrefix, _candidate);
                    -- check that the secondary table exists and is non empty
                    call sp_rows(_secondaryTable);
                    -- if so call the cross matching procedure
                    if @rows > 0 then
                        call sp_crossMatch(_primaryTable, _secondaryTable, _matchTable,
                                           _theta, _mode, _raMin, _raMax, _deltaRa);
                    end if;
                    set _minChunk = _minChunk + 1;
                end while;

                set _stripe = _stripe + 1;        
            end while;

        end if;

        set _chunk = _chunk + 1;
    end while;

end;
//
/* ---------------------------------------------------------------- */


/* ----------------------------------------------------------------
   Equivalent to calling sp_crossMatchChunk for all chunks overlapping
   the given ra range in the given stripe.
   
   WARNING: assumes _theta is <= 1 arcminute.
   ---------------------------------------------------------------- */
create procedure sp_crossMatchStripe(_stripe          int,
                                     _primaryPrefix   varchar(255),
                                     _secondaryPrefix varchar(255),
                                     _matchTable      varchar(255),                                     
                                     _theta           double precision,
                                     _mode            int,
                                     _raMin           double precision,
                                     _raMax           double precision)
    modifies sql data
    comment 'performs a radius theta cross-match between the chunks overlapping the given ra range within the given stripe'
begin
    declare _numChunks int;
    declare _minChunk  int;
    declare _maxChunk  int;

    select numChunks from MemStripes where stripeId = _stripe into _numChunks;
    set _minChunk = (_stripe + 258)*1028 + 
                    (floor((_raMin * _numChunks) / 360)  % _numChunks);
    set _maxChunk = (_stripe + 258)*1028 + 
                    (floor((_raMax * _numChunks) / 360)  % _numChunks);
    call sp_crossMatchChunks(_minChunk, _maxChunk, 
                             _primaryPrefix, _secondaryPrefix, _matchTable,
                             _theta, _mode);
end;
//
/* ---------------------------------------------------------------- */
