/*!
    \file       bustcache.cpp
    \brief      Used to defeat the OS filesystem cache - given the name of an
                input file, performs random 1MB reads all over the file until
                some specified number of megabytes have been read. To make sure
                caches are cleaned for sure, don't use this script: reboot
                instead.

                To be used for LSST partitioning strategy tests.

    \author     Serge Monkewitz
 */

#include <exception>
#include <iostream>
#include <sstream>

#include <cstdlib>
#include <cstring>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>

#include "prng.h"


// ----------------------------------------------------------------
//  Miscellaneous helper functions

/*! Prints usage directions for the program to standard out. */
void printUsage(char const * const progName)
{
using namespace std;

    cout << 
        "\nUsage: " << progName << " --help\n"
        "  Prints out program usage information\n\n";
    cout << 
        "    " << progName << " <file_name> <N>\n\n"
        "  Reads 1MB chunks at random locations in the given file (which must\n"
        "  be at least 1GB but should preferrably be larger) until <N> megabytes\n"
        "  have been read.\n" << endl;
}


/*! Helper function for converting a string to some other type */
template <class T>
bool fromString(T & t, char const * const s)
{
    std::istringstream iss(s);
    return !(iss >> t).fail();
}


class Exception : public std::exception
{
public :
    Exception(std::string const & msg) : _msg(msg) {}
    ~Exception() throw() {}
    virtual char const * what() const throw() { return _msg.c_str(); }

private:
    std::string _msg;
};


class Buffer
{
public :
    
    explicit Buffer(std::size_t const cap)
        : _data(0), _capacity(0)
    {
        if (cap > 0) { _data = new unsigned char[cap]; _capacity = cap; }
    }
    
    ~Buffer() { if (_data) { delete[] _data; } }
    
    std::size_t capacity() const { return _capacity; }
    unsigned char * data() { return _data; }

private :

    unsigned char * _data;
    std::size_t     _capacity;
};


class File
{
public :

    explicit File(std::string const & name)
        : _fd(-1), _size(0)
    {
        init(name.c_str());
    }
    explicit File(char const * const name)
        : _fd(-1), _size(0)
    {
        init(name);
    }

    ~File()
    {
        if (_fd != -1) { ::close(_fd); }
    }

    off_t getSize() const { return _size; }

    void randomRead(Buffer & buf)
    {
        off_t off = static_cast<off_t>(lsst::random() * _size);
        if (off > _size - static_cast<off_t>(buf.capacity()))
        {
            off = _size - buf.capacity();
        }
        if (::pread(_fd, buf.data(), buf.capacity(), off) < 0)
        {
            throw Exception("random read failed");
        }
    }
    
private :

    void init(char const * const name)
    {
        _fd = ::open(name, O_RDONLY);
        if (_fd == -1)
        {
            throw Exception(std::strerror(errno));
        }
        struct stat s;
        if (::fstat(_fd, &s) == -1)
        {
            ::close(_fd);
            throw Exception(std::strerror(errno));            
        }
        _size = s.st_size;
    }

    int   _fd;
    off_t _size;

};

// ----------------------------------------------------------------

int main(int const argc, char const * const * const argv)
{
using namespace std;

    if (argc < 2 || argc > 3)
    {
        cerr << "Invalid argument list: "
                " --help displays usage instructions." << endl;
        return EXIT_FAILURE;        
    }
    if (strncmp(argv[1], "--help", 6) == 0 && argc == 2)
    {
        printUsage(argv[0]);
        return EXIT_SUCCESS;
    }
    else if (argc != 3)
    {
        cerr << "Not enough arguments: "
                " --help displays usage instructions." << endl;
        return EXIT_FAILURE;                
    }
    int megabytes;
    bool ok = fromString<int>(megabytes, argv[2]);
    if (!ok || megabytes < 128 || megabytes > 128000)
    {
        cerr << "Error: second argument must be an integer between "
                "128 and 128000 (128MB and 128GB)." << endl;
        return EXIT_FAILURE;
    }
    
    lsst::initRandom();

    try
    {
        Buffer buf(1024*1024);
        File   file(argv[1]);
        if (file.getSize() < 1024*1024*1024)
        {
            cerr << "Cache-busting file is too small - try again with a "
                    "file of at least 1 GB" << endl;
            return EXIT_FAILURE;
        }
        for (int i = 0; i < megabytes; ++i)
        {
            file.randomRead(buf);
        }
    }
    catch (exception & ex)
    {
        cout << "Error: " << ex.what();
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}
