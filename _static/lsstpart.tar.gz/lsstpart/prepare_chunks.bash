#! /usr/local/bin/bash
#
# ----------------------------------------------------------------
#
#   Script which performs setup steps for LSST chunk based 
#   spatial partitioning tests
#
#   The following scripts need to have been run
#   before the this script can be run:
#
#   prepare.bash            - loads USNO B test data
#
# ----------------------------------------------------------------

set -e

# Ensure working directory is the script directory
cur_dir=`pwd`
script_dir=`dirname $0`
if test "X" = "X$script_dir" ; then
    script_dir=cur_dir
else
    cd $script_dir
    script_dir=`pwd`
fi
echo "Running from script directory: $script_dir"

if test "X" = "X$TEST_DB" ; then
    echo "Please set the TEST_DB environment variable to the"
    echo "name of the MySQL database you want to use for testing"
    echo "and rerun the script"
    exit 1
fi

if test "X" = "X$IOSTAT_PARMS" ; then
    echo "Warning: IOSTAT_PARMS environment variable is undefined or empty."
    echo "         By default, iostat will be run as 'iostat -cdx 30'."
    IOSTAT_PARMS="-cdx 30"
fi

# Setup log file to record what's going on
LOGFILE=../logs/prepare_chunks.log
rm -f $LOGFILE
touch $LOGFILE

# Load the test region boundaries
. test_regions.bash




# ----------------------------------------------------------------
# 1. Get chunk ID lists for test regions
# ----------------------------------------------------------------

HI_CHUNKS=` chunkgen 10800 105 $HI_DEC_MIN  $HI_DEC_MAX  $HI_RA_MIN  $HI_RA_MAX`
LO_CHUNKS=` chunkgen 10800 105 $LO_DEC_MIN  $LO_DEC_MAX  $LO_RA_MIN  $LO_RA_MAX`
AVG_CHUNKS=`chunkgen 10800 105 $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX`

# ----------------------------------------------------------------
# 2. Create all chunk tables, fat and skinny
# ----------------------------------------------------------------

cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------
        | Installing chunks schema ...
================================================================
END_OF_CAT

for i in $HI_CHUNKS
do
    skinny="ChHi_1_$i"
    fat="ChHiFat_1_$i"
    SQL="DROP   TABLE IF EXISTS $skinny;
         CREATE TABLE $skinny LIKE Object;
         ALTER  TABLE $skinny DROP INDEX idx_spatial;
         ALTER  TABLE $skinny CHANGE COLUMN id id BIGINT NOT NULL;
         ALTER  TABLE $skinny DROP PRIMARY KEY;
         DROP   TABLE IF EXISTS $fat;
         CREATE TABLE $fat LIKE FatObjectTemplate;
         ALTER  TABLE $fat CHANGE COLUMN id id BIGINT NOT NULL;
         ALTER  TABLE $fat DROP PRIMARY KEY;"    
    mysql $TEST_DB -e "$SQL" >> $LOGFILE 2>&1
done
for i in $LO_CHUNKS
do
    skinny="ChLo_1_$i"
    fat="ChLoFat_1_$i"
    SQL="DROP   TABLE IF EXISTS $skinny;
         CREATE TABLE $skinny LIKE Object;
         ALTER  TABLE $skinny DROP INDEX idx_spatial;
         ALTER  TABLE $skinny CHANGE COLUMN id id BIGINT NOT NULL;
         ALTER  TABLE $skinny DROP PRIMARY KEY;
         DROP   TABLE IF EXISTS $fat;
         CREATE TABLE $fat LIKE FatObjectTemplate;
         ALTER  TABLE $fat CHANGE COLUMN id id BIGINT NOT NULL;
         ALTER  TABLE $fat DROP PRIMARY KEY;"    
    mysql $TEST_DB -e "$SQL" >> $LOGFILE 2>&1
done
for i in $AVG_CHUNKS
do
    skinny="ChAvg_1_$i"
    fat="ChAvgFat_1_$i"
    SQL="DROP   TABLE IF EXISTS $skinny;
         CREATE TABLE $skinny LIKE Object;
         ALTER  TABLE $skinny DROP INDEX idx_spatial;
         ALTER  TABLE $skinny CHANGE COLUMN id id BIGINT NOT NULL;
         ALTER  TABLE $skinny DROP PRIMARY KEY;
         DROP   TABLE IF EXISTS $fat;
         CREATE TABLE $fat LIKE FatObjectTemplate;
         ALTER  TABLE $fat CHANGE COLUMN id id BIGINT NOT NULL;
         ALTER  TABLE $fat DROP PRIMARY KEY;"    
    mysql $TEST_DB -e "$SQL" >> $LOGFILE 2>&1
done


cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 3. Load data into skinny chunk tables
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------
        | Loading skinny chunk tables:
        | $TIMESTAMP ...
================================================================

END_OF_CAT

iostat $IOSTAT_PARMS >> $LOGFILE &
IOSTAT_PID="$(jobs -p %%)"

for i in $HI_CHUNKS
do
    skinny="ChHi_1_$i"
    echo "Loading $skinny ..." >> $LOGFILE
    (time mysql $TEST_DB -e "INSERT INTO $skinny SELECT * FROM Object WHERE chunkId = $i;") >> $LOGFILE 2>&1
done
for i in $LO_CHUNKS
do
    skinny="ChLo_1_$i"
    echo "Loading $skinny ..." >> $LOGFILE
    (time mysql $TEST_DB -e "INSERT INTO $skinny SELECT * FROM Object WHERE chunkId = $i;") >> $LOGFILE 2>&1
done
for i in $AVG_CHUNKS
do
    skinny="ChAvg_1_$i"
    echo "Loading $skinny ..." >> $LOGFILE
    (time mysql $TEST_DB -e "INSERT INTO $skinny SELECT * FROM Object WHERE chunkId = $i;") >> $LOGFILE 2>&1
done

kill $IOSTAT_PID

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 4. Load fat tables from skinny ones
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------
        | Loading fat chunk tables:
        | $TIMESTAMP ...
================================================================

END_OF_CAT

iostat $IOSTAT_PARMS >> $LOGFILE &
IOSTAT_PID="$(jobs -p %%)"

skinny2fat=`cat ../gen/skinny_to_fat.sql`

for i in $HI_CHUNKS
do
    skinny="ChHi_1_$i"
    fat="ChHiFat_1_$i"
    (time mysql $TEST_DB -e "INSERT INTO $fat SELECT $skinny2fat FROM $skinny;") >> $LOGFILE 2>&1
done
for i in $LO_CHUNKS
do
    skinny="ChLo_1_$i"
    fat="ChLoFat_1_$i"
    (time mysql $TEST_DB -e "INSERT INTO $fat SELECT $skinny2fat FROM $skinny;") >> $LOGFILE 2>&1
done
for i in $AVG_CHUNKS
do
    skinny="ChAvg_1_$i"
    fat="ChAvgFat_1_$i"
    (time mysql $TEST_DB -e "INSERT INTO $fat SELECT $skinny2fat FROM $skinny;") >> $LOGFILE 2>&1
done

kill $IOSTAT_PID

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT


# ----------------------------------------------------------------
#
# Note that for this test setup, the granularity of reads will be
# a whole chunk, so no need to create any indexes.
#
# ----------------------------------------------------------------
