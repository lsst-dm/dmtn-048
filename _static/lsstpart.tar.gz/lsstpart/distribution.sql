# Determine per-chunk object distribution, and use it to
# derive stripe and chunk densities. These densities will in turn
# be used to pick a high, avergae, and low density region for testing
# the various proposed partitioning strategies.

# Create distirbution tables
DROP TABLE IF EXISTS ObjectDistribution;
DROP TABLE IF EXISTS ObjectFineDistribution;

CREATE TABLE ObjectDistribution (
    chunkId    INT      NOT NULL,
    chunkObjs  INT      NOT NULL,
    chunkArea  DOUBLE   NOT NULL,
    stripeId   SMALLINT NOT NULL,
    stripeArea DOUBLE   NOT NULL,
    raMin      DOUBLE   NOT NULL,
    raMax      DOUBLE   NOT NULL,
    decMin     DOUBLE   NOT NULL,
    decMax     DOUBLE   NOT NULL
);

CREATE TABLE ObjectFineDistribution LIKE ObjectDistribution;

# Count objects in coarse and fine chunks
INSERT INTO ObjectDistribution
    SELECT chunkId, COUNT(id), 0, stripeId, 0, 0, 0, 0, 0 FROM Object
    GROUP BY chunkId;

INSERT INTO ObjectFineDistribution
    SELECT fineChunkId, COUNT(id), 0, fineStripeId, 0, 0, 0, 0, 0 FROM Object
    GROUP BY fineChunkId;

# Set areas, and bounds for coarse and fine chunks 
UPDATE ObjectDistribution AS od
    INNER JOIN ObjectStripes AS s ON od.stripeId = s.stripeId
    SET od.stripeArea = (2*PI()*(sin(RADIANS(IF(s.decMax > 90, 90, s.decMax))) - 
                                 sin(RADIANS(IF(s.decMin < -90, -90, s.decMin))))),
        od.chunkArea  = (2*PI()*(sin(RADIANS(IF(s.decMax > 90, 90, s.decMax))) -
                                 sin(RADIANS(IF(s.decMin < -90, -90, s.decMin)))))/s.numChunks,
        od.decMin     = s.decMin,
        od.decMax     = s.decMax;

UPDATE ObjectDistribution AS od
    INNER JOIN ObjectChunks AS c ON od.chunkId = c.chunkId
    SET od.raMin = c.raMin,
        od.raMax = c.raMax;

UPDATE ObjectFineDistribution AS od
    INNER JOIN ObjectFineStripes AS s ON od.stripeId = s.stripeId
    SET od.stripeArea = (2*PI()*(sin(RADIANS(IF(s.decMax > 90, 90, s.decMax))) - 
                                 sin(RADIANS(IF(s.decMin < -90, -90, s.decMin))))),
        od.chunkArea  = (2*PI()*(sin(RADIANS(IF(s.decMax > 90, 90, s.decMax))) -
                                 sin(RADIANS(IF(s.decMin < -90, -90, s.decMin)))))/s.numChunks,
        od.decMin     = s.decMin,
        od.decMax     = s.decMax;

UPDATE ObjectFineDistribution AS od
    INNER JOIN ObjectFineChunks AS c ON od.chunkId = c.chunkId
    SET od.raMin = c.raMin,
        od.raMax = c.raMax;


# Unload the coarse chunk and stripe distributions to files
SELECT  stripeId,
        chunkId,
        chunkObjs,
        (chunkObjs/chunkArea) AS density
    FROM ObjectDistribution
    ORDER BY density DESC
    INTO OUTFILE '/tmp/chunkDistribution.csv'
        FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
        LINES TERMINATED BY '\n';

SELECT  stripeId,
        SUM(chunkObjs),
        AVG(chunkObjs),
        SUM(chunkObjs)/stripeArea AS density
    FROM ObjectDistribution
    GROUP BY stripeId
    ORDER BY density DESC
    INTO OUTFILE '/tmp/stripeDistribution.csv'
        FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
        LINES TERMINATED BY '\n';

