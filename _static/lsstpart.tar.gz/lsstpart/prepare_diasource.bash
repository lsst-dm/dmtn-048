#! /usr/local/bin/bash
#
# ----------------------------------------------------------------
#
#   Script which creates populates the DIASource table with fake
#   entries for the test regions under consideration.
#
#   The following scripts need to have been run
#   before the this script can be run:
#
#   prepare.bash            - loads USNO B test data
#
# ----------------------------------------------------------------

set -e

# Ensure working directory is the script directory
cur_dir=`pwd`
script_dir=`dirname $0`
if test "X" = "X$script_dir" ; then
    script_dir=cur_dir
else
    cd $script_dir
    script_dir=`pwd`
fi
echo "Running from script directory: $script_dir"

if test "X" = "X$TEST_DB" ; then
    echo "Please set the TEST_DB environment variable to the"
    echo "name of the MySQL database you want to use for testing"
    echo "and rerun the script"
    exit 1
fi

if test "X" = "X$IOSTAT_PARMS" ; then
    echo "Warning: IOSTAT_PARMS environment variable is undefined or empty."
    echo "         By default, iostat will be run as 'iostat -cdx 5'."
    IOSTAT_PARMS="-cdx 5"
fi

# Setup log file to record what's going on
LOGFILE=../logs/prepare_diasource.log
rm -f $LOGFILE
touch $LOGFILE

# Load the test region boundaries
. test_regions.bash


# ----------------------------------------------------------------
# 1. Get fine chunk ID lists for test regions
# ----------------------------------------------------------------

HI_CHUNKS=` chunkgen 10800 21 $HI_DEC_MIN  $HI_DEC_MAX  $HI_RA_MIN  $HI_RA_MAX`
LO_CHUNKS=` chunkgen 10800 21 $LO_DEC_MIN  $LO_DEC_MAX  $LO_RA_MIN  $LO_RA_MAX`
AVG_CHUNKS=`chunkgen 10800 21 $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX`



# ----------------------------------------------------------------
# 2. Read fine chunk tables into memory
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------
        | Loading test regions into memory:
        | $TIMESTAMP ...
================================================================

END_OF_CAT

SQL="DROP TABLE IF EXISTS InMemoryObject;
     CREATE TABLE InMemoryObject LIKE Object;
     ALTER TABLE InMemoryObject ENGINE = MEMORY;
     ALTER TABLE InMemoryObject CHANGE COLUMN id id BIGINT NOT NULL;
     ALTER TABLE InMemoryObject DROP PRIMARY KEY;
     ALTER TABLE InMemoryObject DROP INDEX idx_spatial;"

mysql $TEST_DB -e "$SQL"

for i in $HI_CHUNKS
do
    table="FcHi_1_$i"
    mysql $TEST_DB -e "INSERT INTO InMemoryObject SELECT * from $table;" >> $LOGFILE 2>&1
done
for i in $LO_CHUNKS
do
    table="FcLo_1_$i"
    mysql $TEST_DB -e "INSERT INTO InMemoryObject SELECT * from $table;" >> $LOGFILE 2>&1
done
for i in $AVG_CHUNKS
do
    table="FcAvg_1_$i"
    mysql $TEST_DB -e "INSERT INTO InMemoryObject SELECT * from $table;" >> $LOGFILE 2>&1
done

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 3. Create perturbed subset of Objects in test region - note
#    we create enough DIASource objects to result in 1 in 100
#    Objects matching a DIA Source
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------
        | Creating perturbed Object subset:
        | $TIMESTAMP ...
================================================================

END_OF_CAT

rm -f /tmp/diasource.csv /tmp/noise.csv
(time objgen varying 0.01 2.5e-4 /tmp/diasource.csv $TEST_DB InMemoryObject) >> $LOGFILE 2>&1
(time objgen varying 0.001 2.5e-3 /tmp/noise.csv $TEST_DB InMemoryObject) >> $LOGFILE 2>&1

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 4. Load and index DIASource table from perturbed Object 
#    positions 
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------
        | Loading DIASource:
        | $TIMESTAMP ...
================================================================

END_OF_CAT

# Load generated DIA source positions (and id of originating USNO-B Object)
SQL="DROP TABLE IF EXISTS DIASourceStage;
     CREATE TABLE DIASourceStage (
         id bigint not null,
         ra double not null,
         decl double not null) ENGINE = MEMORY;
     LOAD DATA LOCAL INFILE '/tmp/diasource.csv' 
         INTO TABLE DIASourceStage 
         FIELDS TERMINATED BY ','
         IGNORE 3 LINES (id, ra, decl);"

(time mysql $TEST_DB -e "$SQL") >> $LOGFILE 2>&1

# Load actual DIASource table from DIASourceStage
SQL="TRUNCATE TABLE DIASource;
     INSERT INTO DIASource
     (objectId,ra,decl,zoneId,x,y,z,     
      stripeId,fineStripeId,ampExposureId,filterId,
      movingObjectId,procHistoryId,scId,chunkId,fineChunkId,
      raErr4detection,decErr4detection,raErr4wcs,decErr4wcs,
      xpos,ypos,xposErr,yposErr,cx,cy,cz,taiMidPoint,taiRange,
      fwhmA,fwhmB,fwhmTheta,flux,fluxErr,psfMag,psfMagErr,
      apMag,apMagErr,apDia,petroMag,petroMagErr,
      Ixx,IxxErr,Iyy,IyyErr,Ixy,IxyErr,snr,chi2,
      flag4association,flag4detection,flag4wcs) 
     SELECT  
      id, ra, decl, IF(5399 < floor(decl*60), 5399, floor(decl*60)),
      cos(RADIANS(ra))*cos(RADIANS(decl)), sin(RADIANS(ra))*cos(RADIANS(decl)), sin(RADIANS(decl)),
      floor(IF(5399 < floor(decl*60), 5399, floor(decl*60))/105),
      floor(IF(5399 < floor(decl*60), 5399, floor(decl*60))/21),          
      0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
     FROM DIASourceStage;
     DROP TABLE DIASourceStage;"

SQL2="UPDATE DIASource AS d
        INNER JOIN ObjectStripes AS s ON d.stripeId = s.stripeId
        INNER JOIN ObjectFineStripes AS fs ON d.fineStripeId = fs.stripeId
        SET d.chunkId     = (d.stripeId     +  52)*205  + (floor((d.ra* s.numChunks)/360) %  s.numChunks),
            d.fineChunkId = (d.fineStripeId + 258)*1028 + (floor((d.ra*fs.numChunks)/360) % fs.numChunks);"
    
iostat $IOSTAT_PARMS >> $LOGFILE &
IOSTAT_PID="$(jobs -p %%)"

(time mysql $TEST_DB -e "$SQL") >> $LOGFILE 2>&1
(time mysql $TEST_DB -e "$SQL2") >> $LOGFILE 2>&1;

kill $IOSTAT_PID

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT

