#! /usr/local/bin/bash
#
# ----------------------------------------------------------------
#
#   Script which performs setup steps for LSST fine chunk based 
#   spatial partitioning tests.
#
#   The following scripts need to have been run
#   before this script can be run:
#
#   prepare.bash            - loads USNO B test data
#
#
#   TODO :
#   ======
#
#      At the current fine chunk granularity there will be about 330,000 MyISAM
#      tables on disk for full scale tests: we need to distribute them amongst 
#      databases to avoid filesystem limits (in both UFS on Solaris and ext3
#      on Linux).
#
#      The easiest thing is to have one database per fine stripe, named stripe_XXX,
#      where XXX is the stripeId. That means there will be a maximum of 1028 chunks 
#      per high-level table (Object, DIASource) per database, so we stay within
#      the reasonable limits of a few thousand files per directory. There will still
#      be problems with not being able to keep file descriptors open for all tables
#      which need to be accessed - basically it means for every visit MySQL will
#      have to close and open on the order of 100-200 file descriptors. Depending
#      on exactly what MySQL does on top of that when it opens a table (like reading
#      the schema, etc...), this could be significant. If it is, we would probably
#      want to place table metadata into directories that map to the fastest 15k RPM
#      disk (or SSD) drives we can buy (space for that is negligeable). Data
#      directories would then map to larger capacity disk arrays that need to provide
#      high throughput, but not necessarily high IOPS.
#
#      Also, if we create databases specifically to hold our in-memory tables and we
#      are using Linux, then we can place the corresponding meta-data files into a
#      small ext3 volume in RAM (created and reconstructed each time the server boots)
#      since for a lot (all?) of in-memory tables we don't care if the schema survives
#      a reboot.
#
# ----------------------------------------------------------------

set -e

# Ensure working directory is the script directory
cur_dir=`pwd`
script_dir=`dirname $0`
if test "X" = "X$script_dir" ; then
    script_dir=cur_dir
else
    cd $script_dir
    script_dir=`pwd`
fi
echo "Running from script directory: $script_dir"

if test "X" = "X$TEST_DB" ; then
    echo "Please set the TEST_DB environment variable to the"
    echo "name of the MySQL database you want to use for testing"
    echo "and rerun the script"
    exit 1
fi

if test "X" = "X$IOSTAT_PARMS" ; then
    echo "Warning: IOSTAT_PARMS environment variable is undefined or empty."
    echo "         By default, iostat will be run as 'iostat -cdx 5'."
    IOSTAT_PARMS="-cdx 5"
fi

# Setup log file to record what's going on
LOGFILE=../logs/prepare_fine_chunks.log
rm -f $LOGFILE
touch $LOGFILE

# Load the test region boundaries
. test_regions.bash


# ----------------------------------------------------------------
# 1. Get fine chunk ID lists for test regions
# ----------------------------------------------------------------

HI_CHUNKS=` chunkgen 10800 21 $HI_DEC_MIN  $HI_DEC_MAX  $HI_RA_MIN  $HI_RA_MAX`
LO_CHUNKS=` chunkgen 10800 21 $LO_DEC_MIN  $LO_DEC_MAX  $LO_RA_MIN  $LO_RA_MAX`
AVG_CHUNKS=`chunkgen 10800 21 $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX`


# ----------------------------------------------------------------
# 2. Create all fine chunk tables, fat and skinny
# ----------------------------------------------------------------

cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------
        | Installing fine chunks schema ...
================================================================
END_OF_CAT

for i in $HI_CHUNKS
do
    skinny="FcHi_1_$i"
    fat="FcHiFat_1_$i"
    SQL="DROP   TABLE IF EXISTS $skinny;
         CREATE TABLE $skinny LIKE Object;
         ALTER  TABLE $skinny DROP INDEX idx_spatial;
         ALTER  TABLE $skinny CHANGE COLUMN id id BIGINT NOT NULL;
         ALTER  TABLE $skinny DROP PRIMARY KEY;
         DROP   TABLE IF EXISTS $fat;
         CREATE TABLE $fat LIKE FatObjectTemplate;
         ALTER  TABLE $fat CHANGE COLUMN id id BIGINT NOT NULL;
         ALTER  TABLE $fat DROP PRIMARY KEY;"
    mysql $TEST_DB -e "$SQL" >> $LOGFILE 2>&1
done
for i in $LO_CHUNKS
do
    skinny="FcLo_1_$i"
    fat="FcLoFat_1_$i"
    SQL="DROP   TABLE IF EXISTS $skinny;
         CREATE TABLE $skinny LIKE Object;
         ALTER  TABLE $skinny DROP INDEX idx_spatial;
         ALTER  TABLE $skinny CHANGE COLUMN id id BIGINT NOT NULL;
         ALTER  TABLE $skinny DROP PRIMARY KEY;
         DROP   TABLE IF EXISTS $fat;
         CREATE TABLE $fat LIKE FatObjectTemplate;
         ALTER  TABLE $fat CHANGE COLUMN id id BIGINT NOT NULL;
         ALTER  TABLE $fat DROP PRIMARY KEY;"
    mysql $TEST_DB -e "$SQL" >> $LOGFILE 2>&1
done
for i in $AVG_CHUNKS
do
    skinny="FcAvg_1_$i"
    fat="FcAvgFat_1_$i"
    SQL="DROP   TABLE IF EXISTS $skinny;
         CREATE TABLE $skinny LIKE Object;
         ALTER  TABLE $skinny DROP INDEX idx_spatial;
         ALTER  TABLE $skinny CHANGE COLUMN id id BIGINT NOT NULL;
         ALTER  TABLE $skinny DROP PRIMARY KEY;
         DROP   TABLE IF EXISTS $fat;
         CREATE TABLE $fat LIKE FatObjectTemplate;
         ALTER  TABLE $fat CHANGE COLUMN id id BIGINT NOT NULL;
         ALTER  TABLE $fat DROP PRIMARY KEY;"
    mysql $TEST_DB -e "$SQL" >> $LOGFILE 2>&1
done


cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 3. Load data into skinny chunk tables
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------
        | Loading fine skinny chunk tables:
        | $TIMESTAMP ...
================================================================

END_OF_CAT

iostat $IOSTAT_PARMS >> $LOGFILE &
IOSTAT_PID="$(jobs -p %%)"

for i in $HI_CHUNKS
do
    s=`echo "$i/1028 - 258" | bc`
    skinny="FcHi_1_$i"
    echo "Loading $skinny ..." >> $LOGFILE
    (time mysql $TEST_DB -e "INSERT INTO $skinny SELECT * FROM Object WHERE fineStripeId = $s and fineChunkId = $i;") >> $LOGFILE 2>&1
done
for i in $LO_CHUNKS
do
    s=`echo "$i/1028 - 258" | bc`
    skinny="FcLo_1_$i"
    echo "Loading $skinny ..." >> $LOGFILE
    (time mysql $TEST_DB -e "INSERT INTO $skinny SELECT * FROM Object WHERE fineStripeId = $s and fineChunkId = $i;") >> $LOGFILE 2>&1
done
for i in $AVG_CHUNKS
do
    s=`echo "$i/1028 - 258" | bc`
    skinny="FcAvg_1_$i"
    echo "Loading $skinny ..." >> $LOGFILE
    (time mysql $TEST_DB -e "INSERT INTO $skinny SELECT * FROM Object WHERE fineStripeId = $s and fineChunkId = $i;") >> $LOGFILE 2>&1
done

kill $IOSTAT_PID

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 4. Load fat tables from skinny ones
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------
        | Loading fine fat chunk tables:
        | $TIMESTAMP ...
================================================================

END_OF_CAT

iostat $IOSTAT_PARMS >> $LOGFILE &
IOSTAT_PID="$(jobs -p %%)"

skinny2fat=`cat ../gen/skinny_to_fat.sql`

for i in $HI_CHUNKS
do
    skinny="FcHi_1_$i"
    fat="FcHiFat_1_$i"
    (time mysql $TEST_DB -e "INSERT INTO $fat SELECT $skinny2fat FROM $skinny;") >> $LOGFILE 2>&1
done
for i in $LO_CHUNKS
do
    skinny="FcLo_1_$i"
    fat="FcLoFat_1_$i"
    (time mysql $TEST_DB -e "INSERT INTO $fat SELECT $skinny2fat FROM $skinny;") >> $LOGFILE 2>&1
done
for i in $AVG_CHUNKS
do
    skinny="FcAvg_1_$i"
    fat="FcAvgFat_1_$i"
    (time mysql $TEST_DB -e "INSERT INTO $fat SELECT $skinny2fat FROM $skinny;") >> $LOGFILE 2>&1
done

kill $IOSTAT_PID

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 5. Load chunk -> table mapping (will eventually get used 
#    to simulate partition-swap approach to updates)
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------
        | Loading chunk to table map
        | $TIMESTAMP ...
================================================================

END_OF_CAT


# Note: This table will have lots of transactional concurrent updates -
# MyISAM storage engine probably isn't such a good fit here (probably
# InnoDB for now, Falcon once 5.2 comes around, row level locking would
# be desireable).
SQL="DROP TABLE IF EXISTS FineChunkToTableMap;
     DROP TABLE IF EXISTS FineChunkToFatTableMap;

     CREATE TABLE FineChunkToTableMap (
         chunkId   INT NOT NULL PRIMARY KEY,
         version   INT NOT NULL,
         tableName CHAR(32) NOT NULL
     );
     CREATE TABLE FineChunkToFatTableMap LIKE FineChunkToTableMap;"

mysql $TEST_DB -e "$SQL" >> $LOGFILE 2>&1

# load the mapping table
for i in $HI_CHUNKS
do
    skinny="FcHi_1_$i"
    fat="FcHiFat_1_$i"
    mysql $TEST_DB -e "INSERT INTO FineChunkToTableMap VALUES ($i, 1, '$skinny'); INSERT INTO FineChunkToFatTableMap VALUES ($i, 1, '$fat');" >> $LOGFILE 2>&1
done
for i in $LO_CHUNKS
do
    skinny="FcLo_1_$i"
    fat="FcLoFat_1_$i"
    mysql $TEST_DB -e "INSERT INTO FineChunkToTableMap VALUES ($i, 1, '$skinny'); INSERT INTO FineChunkToFatTableMap VALUES ($i, 1, '$fat');" >> $LOGFILE 2>&1
done
for i in $AVG_CHUNKS
do
    skinny="FcAvg_1_$i"
    fat="FcAvgFat_1_$i"
    mysql $TEST_DB -e "INSERT INTO FineChunkToTableMap VALUES ($i, 1, '$skinny'); INSERT INTO FineChunkToFatTableMap VALUES ($i, 1, '$fat');" >> $LOGFILE 2>&1
done

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT

# ----------------------------------------------------------------
#
# Note that for this test setup, the granularity of reads will be
# a whole chunk, so no need to create any indexes.
#
# ----------------------------------------------------------------
