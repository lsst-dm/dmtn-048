#! /usr/local/bin/python

# LSST Object table size: 1,105 bytes. Adding 50% to
# this for overhead gives us 1,657 bytes. The schema
# below takes ~100 bytes, not counting junk. So,
# generate 200 double (8 byte) junk columns to
# approximate final row size.
numColumns = 200
fatSchemaHead = """
DROP TABLE IF EXISTS FatObjectTemplate;

CREATE TABLE FatObjectTemplate (
    id           BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    ra           DECIMAL(8,5) NOT NULL,
    decl         DECIMAL(8,5) NOT NULL,
    pm_ra        DECIMAL(8,5) NOT NULL,
    pm_raErr     SMALLINT NOT NULL,
    pm_decl      DECIMAL(8,5) NOT NULL,
    pm_decErr    SMALLINT NOT NULL,
    epoch        DECIMAL(6,1) NOT NULL,
    bMag         DECIMAL(5,3) NOT NULL,
    bErr         DECIMAL(5,3) NOT NULL,
    rMag         DECIMAL(5,3) NOT NULL,
    rErr         DECIMAL(5,3) NOT NULL,
    bMag2        DECIMAL(5,3) NOT NULL,
    bErr2        DECIMAL(5,3) NOT NULL,
    rMag2        DECIMAL(5,3) NOT NULL,
    rErr2        DECIMAL(5,3) NOT NULL,
    zoneId       INT NOT NULL DEFAULT 0,
    stripeId     SMALLINT NOT NULL DEFAULT 0,
    fineStripeId SMALLINT NOT NULL DEFAULT 0,
    chunkId      INT NOT NULL DEFAULT 0,
    fineChunkId  INT NOT NULL DEFAULT 0,
    x            DOUBLE NOT NULL DEFAULT 0.0,
    y            DOUBLE NOT NULL DEFAULT 0.0,
    z            DOUBLE NOT NULL DEFAULT 0.0"""
f = open('fat.sql', 'w')
f.write(fatSchemaHead)
for i in xrange(numColumns):
    f.write(",\n    c%03d    DOUBLE NOT NULL DEFAULT 0.0" % (i+1))
f.write("\n);\n\n")
fatSchemaHead = fatSchemaHead.replace('FatObjectTemplate', 'InMemoryFineFatChunkTemplate')
fatSchemaHead = fatSchemaHead.replace('AUTO_INCREMENT', '')
f.write(fatSchemaHead)
for i in xrange(numColumns):
    f.write(",\n    c%03d    DOUBLE NOT NULL DEFAULT 0.0" % (i+1))
f.write(",\n    INDEX idx_zone USING BTREE (zoneId)\n) ENGINE = MEMORY;\n")
f.close()

f = open('skinny_to_fat.sql', 'w')
f.write("id,ra,decl,pm_ra,pm_raErr,pm_decl,pm_decErr,epoch,")
f.write("bMag,bErr,rMag,rErr,bMag2,bErr2,rMag2,rErr2,")
f.write("zoneId,stripeId,fineStripeId,chunkId,fineChunkId,x,y,z")
for i in xrange(numColumns):
    f.write(",RAND()");
f.close()
