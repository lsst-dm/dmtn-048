#! /usr/local/bin/bash
#
# ----------------------------------------------------------------
#
#   Script which performs setup steps for LSST stripe based 
#   spatial partitioning tests
#
#   The following scripts need to have been run
#   before the this script can be run:
#
#   prepare.bash            - loads USNO B test data
#
# ----------------------------------------------------------------

set -e

# Ensure working directory is the script directory
cur_dir=`pwd`
script_dir=`dirname $0`
if test "X" = "X$script_dir" ; then
    script_dir=cur_dir
else
    cd $script_dir
    script_dir=`pwd`
fi
echo "Running from script directory: $script_dir"

if test "X" = "X$TEST_DB" ; then
    echo "Please set the TEST_DB environment variable to the"
    echo "name of the MySQL database you want to use for testing"
    echo "and rerun the script"
    exit 1
fi

if test "X" = "X$IOSTAT_PARMS" ; then
    echo "Warning: IOSTAT_PARMS environment variable is undefined or empty."
    echo "         By default, iostat will be run as 'iostat -cdx 30'."
    IOSTAT_PARMS="-cdx 30"
fi

# Setup log file to record what's going on
LOGFILE=../logs/prepare_stripes.log
rm -f $LOGFILE
touch $LOGFILE

# Load the stripe table names and their IDs
. stripe_vars.bash

# Load test region descriptions
. test_regions.bash

# Set maximum size of a MySQL in-memory table to 8GB
mysql -e "SET GLOBAL max_heap_table_size=8589934592;"

# Function that runs a read test
#
# Parameters
# 1      The name of the stripe table to load data into memory from
# 2      The minimum dec of objects to load
# 3      The maximum dec of objects to load
# 4      The minimum ra of objects to load
# 5      The maximum ra of objects to load
readTest()
{
    SQL="DROP TABLE IF EXISTS InMemoryObject;
         CREATE TABLE InMemoryObject LIKE $1;
         ALTER TABLE InMemoryObject ENGINE = MEMORY;
         ALTER TABLE InMemoryObject CHANGE COLUMN id id BIGINT NOT NULL;
         ALTER TABLE InMemoryObject DROP PRIMARY KEY;
         ALTER TABLE InMemoryObject DROP INDEX idx_ra;
         ALTER TABLE InMemoryObject DROP INDEX idx_zone_ra;"

    mysql $TEST_DB -e "$SQL" >> $LOGFILE 2>&1

    # Setup WHERE clause.
    cmp=$(echo "if($4 > $5) 1" | bc)
    if [[ $cmp -eq 1 ]]
    then
        WHERE_CLAUSE="((ra >= $4) or (ra < $5))"
    else
        WHERE_CLAUSE="ra >= $4 and ra < $5"
    fi
    WHERE_CLAUSE="WHERE decl >= $2 and decl < $3 and $WHERE_CLAUSE"

    # empty MySQL server caches
    mysql $TEST_DB -e "FLUSH TABLES;" >> $LOGFILE 2>&1

    # start CPU, IO monitoring
    iostat $IOSTAT_PARMS >> $LOGFILE &
    IOSTAT_PID="$(jobs -p %%)"

    # read data into memory
    (time mysql $TEST_DB -e "INSERT INTO InMemoryObject SELECT * FROM $1 $WHERE_CLAUSE;" ) >> $LOGFILE 2>&1

    #stop timer
    kill $IOSTAT_PID

    mysql $TEST_DB -e "SELECT count(*) FROM InMemoryObject" >> $LOGFILE 2>&1
}



# ----------------------------------------------------------------
# 1. Install schema for stripe tables
# ----------------------------------------------------------------

cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------
        | Installing stripes schema ...
================================================================
END_OF_CAT

for table in $SKINNY_TABLES
do
    mysql $TEST_DB -e "DROP TABLE IF EXISTS $table; CREATE TABLE $table LIKE Object; ALTER TABLE $table DROP INDEX idx_spatial;" >> $LOGFILE 2>&1
done
for table in $FAT_TABLES
do
    mysql $TEST_DB -e "DROP TABLE IF EXISTS $table; CREATE TABLE $table LIKE FatObjectTemplate;" >> $LOGFILE 2>&1
done

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 2. Load data into skinny stripe tables
#
#    Fat tables are loaded directly from the skinny ones
#    (instead of reading from Object twice per stripe)
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------
        | Loading skinny stripe tables:
        | $TIMESTAMP ...
================================================================

END_OF_CAT

iostat $IOSTAT_PARMS >> $LOGFILE &
IOSTAT_PID="$(jobs -p %%)"

# Note: loading 3 tables in parallel can be done something like this:
#       (but for now, load tables sequentially)
#
# echo "Loading ObjStripe_Hi[A-C]" >> $LOGFILE
# ( time mysql $TEST_DB -e "INSERT INTO ObjStripe_HiA SELECT * FROM Object WHERE stripeId=1;"; ) >> $LOGFILE 2>&1 &
# JOB1_PID="$(jobs -p %%)"
# ( time mysql $TEST_DB -e "INSERT INTO ObjStripe_HiB SELECT * FROM Object WHERE stripeId=2;"; ) >> $LOGFILE 2>&1 &
# JOB2_PID="$(jobs -p %%)"
# ( time mysql $TEST_DB -e "INSERT INTO ObjStripe_HiC SELECT * FROM Object WHERE stripeId=3;"; ) >> $LOGFILE 2>&1 &
# JOB3_PID="$(jobs -p %%)"
# wait $JOB1_PID;
# wait $JOB2_PID;
# wait $JOB3_PID;

i=0
for table in $SKINNY_TABLES
do
    ( echo "Loading $table ..."; \
      time mysql $TEST_DB -e " INSERT INTO $table SELECT * FROM Object WHERE fineStripeId>=${STRIPE_MIN[$i]} and fineStripeId<${STRIPE_MAX[$i]};"; \
    ) >> $LOGFILE 2>&1
    (( i++ ))
done

kill $IOSTAT_PID

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 3. Load fat tables from skinny ones
#
#    Note: the extra columns in the fat tables are filled with random
#    values to avoid unrealistically small rows with any kind of disk
#    compression enabled. Instead, rows will be unrealistically large.
#    This is ok since we are mostly concerned with worst case behaviour. 
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------
        | Loading fat stripe tables:
        | $TIMESTAMP ...
================================================================

END_OF_CAT

iostat $IOSTAT_PARMS >> $LOGFILE &
IOSTAT_PID="$(jobs -p %%)"

skinny2fat=`cat ../gen/skinny_to_fat.sql`

for skinny in $SKINNY_TABLES
do
    table=`sed 's/[A-C]$/Fat&/' <<< $skinny`
    ( echo "Loading $table from $skinny ..."; \
      time mysql $TEST_DB -e " INSERT INTO $table SELECT $skinny2fat FROM $skinny;"; \
    ) >> $LOGFILE 2>&1
done

kill $IOSTAT_PID

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 4. Create indexes on ra and (zoneId, ra)
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------
        | Creating indexes on stripe tables:
        | $TIMESTAMP ...
================================================================

END_OF_CAT

iostat $IOSTAT_PARMS >> $LOGFILE &
IOSTAT_PID="$(jobs -p %%)"

for table in $SKINNY_TABLES $FAT_TABLES
do
    ( echo "Creating ra index on $table ..."; \
      time mysql $TEST_DB -e "ALTER TABLE $table ADD INDEX idx_ra(ra);"; \
    ) >> $LOGFILE 2>&1
    ( echo "Creating (zoneId, ra) index on $table ..."; \
      time mysql $TEST_DB -e "ALTER TABLE $table ADD INDEX idx_zone_ra(zoneId,ra);"; \
    ) >> $LOGFILE 2>&1
done

kill $IOSTAT_PID

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 5. Simple check of read speed with unsorted index/records
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         ------------------------------------------------
        | Simple read perf test (unsorted index/records)
        | $TIMESTAMP ...
================================================================

END_OF_CAT

readTest ObjStripe_HiB $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 6. Use myisamchk to sort indexes and rows
#
#    Note that for each table:
#        index 1 is on id (the primary key)
#        index 2 is on ra
#        index 3 is on (zoneId, ra)
#
#    (myisamchk cannot handle index names, use creation order)
#
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         ------------------------------------------------
        | Sorting table indexes and records (clustering):
        | $TIMESTAMP ...
================================================================

END_OF_CAT

# WARNING: When clustering indexes with myisamchk,
# *no one* should access mysql.

# flush memory before sorting
mysql $TEST_DB -e "FLUSH TABLES" >> $LOGFILE 2>&1

iostat $IOSTAT_PARMS >> $LOGFILE &
IOSTAT_PID="$(jobs -p %%)"

for table in $SKINNY_TABLES $FAT_TABLES
do
    ( cd /u2/mysql_data/$TEST_DB/; \
      time myisamchk --sort-records=2 --sort-index $table; \
      chgrp mysql $table.MYD $table.MYI; \
    ) >> $LOGFILE 2>&1
done

kill $IOSTAT_PID

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 7. Simple check of read speed with sorted index/records 
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         ------------------------------------------------
        | Simple read perf test (sorted index/records) 
        | $TIMESTAMP ...
================================================================

END_OF_CAT

readTest ObjStripe_HiB $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT

