/*!
    \file       objgen.cpp
    \brief      Used to generate subsets of an Object table. One can either
                attempt to produce a spatially uniformly distributed subset,
                or produce a subset having density within a constant factor
                of the parent table density (where density is measured
                at the final subdivision level of some predetermined spatial
                partitioning of the unit sphere). Objects that are determined
                to be in the random subset can optionally have their positions
                perturbed.

                Finally, given a precalculated distribution table, one can
                randomly generate Objects according to the prescribed densities.

                To be used for LSST partitioning strategy tests.

    \author     Serge Monkewitz
 */

#include <exception>
#include <vector>
#include <algorithm>
#include <iostream>
#include <sstream>
#include <fstream>

#include <cstdlib>
#include <cstring>
#include <cmath>
#include <cassert>
#if defined (HAVE_STDINT_H)
#   include <cstdint>
#else
#   include <inttypes.h>
#endif


#include <mysql++.h>

#include "prng.h"


namespace lsst {

// ----------------------------------------------------------------
//  Global constants

static double const gTwoPi       = 6.2831853071795864770;
static double const gSphereArea  = 2.0 * gTwoPi;
static double const gDegToRad    = 0.017453292519943295770;
static double const gRadToDeg    = 57.295779513082320875;
static double const gArcsecToRad = 0.0000048481368110953599358;


// ----------------------------------------------------------------
//  Miscellaneous helper functions

/*! Prints usage directions for the program to standard out. */
void printUsage(char const * const progName)
{
using namespace std;

    cout << 
        "\nUsage: " << progName << " --help\n"
        "  Prints out program usage information\n\n";
    cout << 
        "    " << progName << " uniform <factor> <csv_file> "
        "<db> <tbl> <distribution_tbl>\n"
        "    " << progName << " varying <factor> <csv_file> "
        "<db> <tbl>\n\n"
        "  Generates a random subset of the database table <tbl> in the given\n"
        "  MySQL database <db>. This table is assumed to contain columns named\n"
        "  id (BIGINT), chunkId (INT), and ra and decl(DOUBLE). If the first\n"
        "  parameter is \"uniform\", then the same database must also contain\n"
        "  a table named <distribution_tbl> with columns chunkId (INT),\n"
        "  chunkObjs (INT), chunkArea, raMin, raMax, decMin, decMax (all\n"
        "  DOUBLE). <factor> must be a floating point number in the range\n"
        "  (0,1). If the first parameter is \"uniform\", then <factor> is used\n"
        "  to produce a subset with as close to constant density as possible,\n"
        "  where the target density is equal to that of a uniform distribution\n"
        "  of N*<factor> objects on the sky (N is the the number of objects in\n"
        "  <tbl>). On the other hand, if the first parameter is \"varying\",\n"
        "  then the spatial distribution of the random subset will vary with\n"
        "  the the distribution of objects in <tbl>; any object in <tbl> will\n"
        "  belong to the random subset with probability <factor>. The output\n"
        "  is stored as a simple list of id values in the ASCII CSV file\n"
        "  <csv_file>.\n\n";

    cout << 
        "    " << progName << " uniform <factor> <sigma> <csv_file> "
        "<db> <tbl> <distribution_tbl>\n"
        "    " << progName << " varying <factor> <sigma> <csv_file> "
        "<db> <tbl>\n\n"
        "  Performs the same actions as the invocations described above,\n"
        "  except that each object assigned to the random subset has its\n"
        "  position perturbed according to a normal distribution with a\n"
        "  standard deviation of <sigma> arc-seconds. The new position is\n"
        "  stored along with the object id in <csv_file>\n\n";

    cout << 
        "    " << progName << " create <factor> <csv_file> "
        "<db> <distribution_tbl> [id_1 id_2 id_3 ...]\n\n"
        "  This creates a table of objects with spatial distribution taken\n"
        "  from the table <distribution_tbl> in database <db>. Specifically,\n"
        "  the generated table will contain objects such that the object density\n"
        "  at location p is roughly <factor>*D(p), where D(p) is the density at\n"
        "  location p given in <distribution_tbl>. An optional list of integer\n"
        "  chunk id values concludes the argument list. These restrict object\n"
        "  generation to the chunks with the given ids.\n\n";
        
    cout << 
        "  Note: " << progName << " must currently be run on the same machine\n"
        "  as the MySQL server process.\n" << endl;
}


/*! Helper function for converting a string to some other type */
template <class T>
bool fromString(T & t, char const * const s)
{
    std::istringstream iss(s);
    return !(iss >> t).fail();
}

class Exception : public std::exception
{
public :
    Exception(std::string const & msg) : _msg(msg) {}
    ~Exception() throw() {}
    virtual char const * what() const throw() { return _msg.c_str(); }

private:
    std::string _msg;
};


// ----------------------------------------------------------------
//  Spatial types (positions and chunks)

/*! Simple POD type for chunk related info we are interested in. */
struct Chunk
{
    int    _id;
    int    _numObjects;
    double _area;
    double _raMin;
    double _raMax;
    double _decMin;
    double _decMax;
};

struct AscendingChunkOrdering
{
    bool operator()(Chunk const & first, Chunk const & second)
    {
        return first._id < second._id;
    }
};


/*! Simple POD type for position related info we are interested in. */
struct Point
{
    uint64_t _id;
    double   _lon;
    double   _lat;

    Point(double const lon, double const lat)
        : _id(0), _lon(lon), _lat(lat)
    {}
    
    Point() 
        : _id(0), _lon(0.0), _lat(0.0)
    {}
    
    /*! Randomly perturbs the point such that the results are distributed
        according to a normal distribution centered on the original point
        and having a standard deviation of \a sigma arcseconds. */
    void perturb(double const sigma);
    
    /*! Picks a point uniformly at random on the unit sphere.*/
    static Point const random();

    /*! Picks a point uniformly at random in the specified annulus.*/
    static Point const random(double const latMin,
                              double const latMax);

    /*! Picks a point uniformly at random in the specified box.*/
    static Point const random(double const lonMin,
                              double const lonMax,
                              double const latMin,
                              double const latMax);
};

void Point::perturb(double const sigma)
{
    double const slon = std::sin(gDegToRad * _lon);
    double const clon = std::cos(gDegToRad * _lon);
    double const slat = std::sin(gDegToRad * _lat);
    double const clat = std::cos(gDegToRad * _lat);

    // original position V 
    double x = clon*clat;
    double y = slon*clat;
    double z = slat;

    double const ang  = lsst::random()*gTwoPi;
    double const sang = std::sin(ang);
    double const cang = std::cos(ang);

    // rotate east vector at V by a random angle 
    double const tx   = - sang*clon*slat - cang*slon;
    double const ty   = - sang*slon*slat + cang*clon;
    double const tz   =   sang*clat;                
    
    // and perturb in this direction by a random angle that is normally
    // distributed with a standard deviation of sigma arcseconds
    double const mag  = gArcsecToRad * sigma * normal();
    double const smag = std::sin(mag);
    double const cmag = std::cos(mag);
    
    // obtain the perturbed position
    x = x*cmag + tx*smag;
    y = y*cmag + ty*smag;
    z = z*cmag + tz*smag;
    
    // finally, convert back to spherical coordinates (in degrees)
    _lon = std::atan2(y, x) * gRadToDeg;
    if (_lon < 0.0) { _lon += 360.0; }
    _lat = std::asin(z) * gRadToDeg;
}

// picks a random z value in the specified latitude bounds
static double latRand(double const latMin,
                      double const latMax)
{
    assert(latMin < latMax && latMin < 90.0 && latMax > -90.0);
    
    double min  = (latMin < -90.0) ? -90.0 : latMin;
    double max  = (latMax >  90.0) ?  90.0 : latMax;
    double smin = std::sin(gDegToRad * min);
    double smax = std::sin(gDegToRad * max);
    double z    = smin + random2() * (smax - smin);

    return std::asin(z) * gRadToDeg;
}

Point const Point::random()
{
    double z   = -1.0 + 2.0 * random2();
    double lat = std::asin(z) * gRadToDeg;
    double lon = random2() * 360.0;
    return Point(lon, lat);
}

Point const Point::random(double const latMin,
                          double const latMax)
{
    return Point(random2() * 360.0, latRand(latMin, latMax));
}

Point const Point::random(double const lonMin,
                          double const lonMax,
                          double const latMin,
                          double const latMax)
{
    assert(lonMin >= 0.0 && lonMin <= 360.0);
    assert(lonMax >= 0.0 && lonMax <= 360.0);

    double lon;
    if (lonMin < lonMax)
    {
        lon = lonMin + random2() * (lonMax - lonMin);
    }
    else
    {
        // wrap-around
        double m = lonMin - 360.0;
        lon = m + random2() * (lonMax - m);
        if (lon < 0) { lon += 360.0; }
    }
    return Point(lon, latRand(latMin, latMax));
}

std::ostream & operator << (std::ostream & os, Point const & p)
{
    os << p._id << ',' << p._lon << ',' << p._lat;
    return os;
}


// ----------------------------------------------------------------
//  Database helper functions

/*! Counts the number of rows in the table named \a tbl. */
std::size_t countRows(mysqlpp::Connection & con,
                      char const * const    tbl)
{
    std::size_t nrows = 0;
    mysqlpp::Query query = con.query();
    query << "select count(*) from " << tbl;
    mysqlpp::Result result = query.store();
    mysqlpp::Row row(result.at(0));
    nrows = row.at(0);
    return nrows;
}


/*! Reads the spatial distribution table \a distributionTable into a vector
    of Chunk objects \a chunks. \a distribution_tbl must have columns 
    named chunkId (of type INT), chunkObjs (INT), and chunkArea, raMin,
    raMax, decMin, decMax (all DOUBLE). */
bool readDistribution(mysqlpp::Connection &          con,
                      std::vector<Chunk> &           chunks,
                      char const * const             distributionTable,
                      std::vector<int> const * const ids = 0)
{
    // reserve space for all chunks
    chunks.clear();
    if (ids == 0 || ids->size() == 0)
    {
        chunks.reserve(countRows(con, distributionTable));
    }
    else
    {
        chunks.reserve(ids->size());
    }

    // read in each chunk
    mysqlpp::Query query = con.query();
    query << "select "
             "    chunkId,"
             "    chunkObjs,"
             "    chunkArea,"
             "    raMin,"
             "    raMax,"
             "    decMin,"
             "    decMax "
             "from " << distributionTable;
    if (ids != 0 && ids->size() > 0)
    {
        query << " where chunkId in (";
        for (std::size_t i = 0; i < ids->size() - 1; ++i)
        {
            query << ids->operator[](i) << ',';
        }
        query << ids->back() << ')';
    }

    mysqlpp::ResUse results = query.use();
	if (!results)
	{
        return false;
    }
	// Get each row in result set
	try
	{
	    mysqlpp::Row row;
        Chunk chunk;
		while (row = results.fetch_row())
		{
            chunk._id         = row.at(0);
            chunk._numObjects = row.at(1);
            chunk._area       = row.at(2);
            chunk._raMin      = row.at(3);
            chunk._raMax      = row.at(4);
            chunk._decMin     = row.at(5);
            chunk._decMax     = row.at(6);
            chunks.push_back(chunk);
		}
	}
    catch (mysqlpp::EndOfResults const &) {}

	// sort on chunkId so we can use binary search for lookups
    std::sort(chunks.begin(), chunks.end(), AscendingChunkOrdering());	
    return chunks.size() > 0;
}


// ----------------------------------------------------------------
//  Implementation of subset picking and point generation

/*! 
    Picks a random subset of the given table with an identical spatial
    distribution (to within a constant factor).
    
    \return     the number of objects in the subset
 */
std::size_t varyingSubset(mysqlpp::Connection & con,
                          std::ostream &        os,
                          char const * const    table,
                          double const          factor,
                          double const          sigma)
{
    std::size_t numObjects = 0;
    mysqlpp::Query query = con.query();
    if (sigma > 0.0)
    {
        // select a random subset and perturb positions
        os << "# id, ra, decl\n"
              "# bigint, double, double\n"
              "# -, degrees, degrees";

        query << "select id, ra, decl from " << table;
        mysqlpp::ResUse results = query.use();
        if (!results)
        {
            return 0;
        }
        try
        {
            mysqlpp::Row row;
            while (row = results.fetch_row())
    	    {
    		    if (coinToss(factor))
        		{
                    Point p;
                    p._id  = row.at(0);
                    p._lon = row.at(1); 
                    p._lat = row.at(2);
                    p.perturb(sigma);
                    os << '\n' << p;
                    ++numObjects;
                }
    		}
        }
        catch (mysqlpp::EndOfResults const &) {}
	}
	else
	{
	    // select a random subset only
        os << "# id\n"
              "# bigint\n"
              "# -";

        query << "select id from " << table;
        mysqlpp::ResUse results = query.use();
        if (!results)
        {
            return 0;
        }
        try
        {
            mysqlpp::Row row;    
            while (row = results.fetch_row())
    	    {
    		    if (coinToss(factor))
        		{
                    os << '\n' << static_cast<mysqlpp::sql_bigint>(row.at(0));
                    ++numObjects;
                }
    		}
		}
        catch (mysqlpp::EndOfResults const &) {}
	}
    return numObjects;
}


/*!
    Pick a random subset of the given table that is as uniformly
    distributed as possible.

    \return     the number of objects in the subset
*/
std::size_t uniformSubset(mysqlpp::Connection & con,
                          std::ostream &        os,
                          char const * const    table,
                          char const * const    distributionTable,
                          double const          factor,
                          double const          sigma)
{
    // Compute target density
    double const targetDensity =
        static_cast<double>(countRows(con, table))*factor / gSphereArea;
    // number of objects in subset
    std::size_t numObjects = 0;
    
    // read in distribution table
    std::vector<Chunk> chunks;
    if (!readDistribution(con, chunks, distributionTable))
    {
        throw Exception("Empty distribution table");
    }
    
    // Issue query
    mysqlpp::Query query = con.query();
    if (sigma > 0.0)
    {
        // select a random subset and perturb positions
        os    << "# id, ra, decl\n"
                 "# bigint, double, double\n"
                 "# -, degrees, degrees";        
        query << "select id, chunkId, ra, decl from " << table;
    }
    else
    {
        // select random subset only
        os    << "# id\n"
                 "# bigint\n"
                 "# -";        
        query << "select id, chunkId from " << table;        
    }
    mysqlpp::ResUse results = query.use();
    if (!results)
    {
        return 0;
    }

    // Stream through results
    try
    {
        mysqlpp::Row row;
        Chunk  chunk(chunks[0]);
        double probability = (targetDensity * chunk._area) / 
                             static_cast<double>(chunk._numObjects);
        while (row = results.fetch_row())
    	{
            int const chunkId = row.at(1);
            if (chunk._id != chunkId)
            {
                // This object belongs to a different chunk than 
                // the last one - lookup the correct chunk.
                chunk._id = chunkId;
                chunk = *std::lower_bound(chunks.begin(), chunks.end(), 
                                          chunk, AscendingChunkOrdering());
                if (chunk._id != chunkId)
                {
                    throw Exception("Table contains a chunk for which "
                        "there is no entry in the distribution table");
                }
                // recompute subset membership probability
                probability = (targetDensity * chunk._area) / 
                              static_cast<double>(chunk._numObjects);
            }
            if (coinToss(probability))
          	{
                if (sigma > 0.0)
                {
                    Point p;
                    p._id  = row.at(0);
                    p._lon = row.at(2); 
                    p._lat = row.at(3);
                    p.perturb(sigma);
                    os << '\n' << p;
                }
                else
                {
                    os << '\n' << static_cast<mysqlpp::sql_bigint>(row.at(0));
                }
                ++numObjects;
            }
        }
    }
    catch (mysqlpp::EndOfResults const &) {}
    
    return numObjects;
}


/*!
    Creates a random Object table according to a given spatial distribution.

    \return     the number of objects created.
*/
std::size_t createObjects(mysqlpp::Connection &    con,
                          std::ostream &           os,
                          std::vector<int> const & gen,
                          char const * const       distributionTable,
                          double const             factor)
{    
    std::vector<Chunk> chunks;
    std::size_t        numObjects = 0;

    // read in distribution table
    if (!readDistribution(con, chunks, distributionTable, &gen))
    {
        throw Exception("Empty distribution table");        
    }

    os << "# id, chunkId, ra, decl\n"
          "# bigint, int, double, double\n"
          "# -, -, degrees, degrees";

    if (gen.size() == 0)
    {
        // generate objects for the requested chunks
        for (std::vector<Chunk>::iterator c(chunks.begin());
             c < chunks.end(); ++c)
        {
            std::size_t n = static_cast<std::size_t>(factor * c->_numObjects); 
            for (std::size_t j = 0; j < n; ++j)
            {
                Point p = Point::random(c->_raMin, c->_raMax,
                                        c->_decMin, c->_decMax);
                p._id = ++numObjects;
                os << '\n' << p._id << ',' << c->_id 
                   << ',' << p._lon << ',' << p._lat;
            }
        }
    }
    return numObjects;
}

}   // end of namespace lsst


int main(int const argc, char const * const * const argv)
{
using namespace std;
using namespace lsst;

    // basic input checking
    if (argc < 2 || (argc > 2 && argc < 6))
    {
        cerr << "Insufficient arguments\n    " << argv[0]
             << " --help displays usage instructions." << endl;
        return EXIT_FAILURE;        
    }
    if (strncmp(argv[1], "--help", 6) == 0 && argc == 2)
    {
        printUsage(argv[0]);
        return EXIT_SUCCESS;
    }

    bool isUniform = strncmp(argv[1], "uniform", 7) == 0;
    bool isVarying = strncmp(argv[1], "varying", 7) == 0;

    initRandom();

    // read in arguments common to all modes
    double factor = 0.0;
    bool   ok     = fromString<double>(factor, argv[2]);
    if (!ok || factor < 0.0 || factor > 1.0)
    {
        cerr << "Invalid argument " << argv[2]
             << "\n    <factor> must be a floating point number between 0 and 1"
             << endl;
        return EXIT_FAILURE;
    }
    
    // 1. Select a random subset of an existing table
    if (isUniform || isVarying)
    {
        // finish reading in arguments
        size_t numObjects = 0;
        double sigma      = 0.0;
        int    tail       = 3;
        
        if (fromString<double>(sigma, argv[3]))
        {
            ++tail;
            if (sigma < 0.0 || sigma > 60.0)
            {
                cerr << "Invalid argument " << argv[3] 
                     << "\n    <sigma> must be an angle between 0 and 60 arcseconds"
                     << endl;
                return EXIT_FAILURE;            
            }
        }
        if ((isUniform && argc != tail + 4) || (isVarying && argc != tail + 3))
        {
            cerr << "Illegal argument list\n    " << argv[0]
                 << " --help displays usage instructions." << endl;
            return EXIT_FAILURE;            
        }
        try
        {
            // open output file
            ofstream csvFile;
            csvFile.open(argv[tail]);
            // make sure no precision is lost when printing doubles
            csvFile.precision(17);

            // connect to MySQL
            mysqlpp::Connection con;
            con.connect(argv[tail + 1]);
            if (!con)
            {
                cerr << "Failed to connect to MySQL server: "
                     << con.error() << endl;
                return EXIT_FAILURE;
            }
            
            // pick subset 
            if (isUniform)
            {
                numObjects = uniformSubset(con, csvFile, argv[tail + 2], 
                                           argv[tail + 3], factor, sigma);
            }
            else
            {
                numObjects = varyingSubset(con, csvFile, argv[tail + 2],
                                           factor, sigma);
            }
            csvFile.close();
        }
        catch(exception & ex)
        {
            cerr << "Error: " << ex.what() << endl;
            return EXIT_FAILURE;
        }
        cout << "Picked a " << (isUniform ? "uniform" : "varying")
             << " subset of table \"" << argv[tail + 2] << "\" in database \"" 
             << argv[tail + 1] << "\" containing " << numObjects
             << " objects" << endl;             
    }
    // 2. Create a random Object table according to a given distribution
    else if (strncmp(argv[1], "create", 6) == 0)
    {
        size_t numObjects = 0;
        try
        {
            vector<int> gen;
            if (argc > 6)
            {
                // Read in an optional chunk list
                gen.reserve(argc - 6);
                int chunkId;
                for (int i = 6; i < argc; ++i)
                {
                    if (!fromString<int>(chunkId, argv[i]))
                    {
                        cerr << "Invalid argument " << argv[i] 
                             << "\n    a chunk id must be a valid integer"
                             << endl;
                         return EXIT_FAILURE;
                    }
                    gen.push_back(chunkId);
                }
                sort(gen.begin(), gen.end());
            }
            
            // open output file
            ofstream csvFile;
            csvFile.open(argv[3]);
            // make sure no precision is lost when printing doubles
            csvFile.precision(17);

            // connect to MySQL
            mysqlpp::Connection con;
            con.connect(argv[4]);
            if (!con)
            {
                cerr << "Failed to connect to MySQL server: "
                     << con.error() << endl;
                return EXIT_FAILURE;
            }
            
            // generate Objects
            numObjects = createObjects(con, csvFile, gen, argv[5], factor);
            csvFile.close();
        }
        catch(exception & ex)
        {
            cerr << "Error: " << ex.what() << endl;
            return EXIT_FAILURE;
        }
        cout << "Created a table containing " << numObjects
             << " objects, based on the spatial distribution given in table \""
             << argv[5] << "\" in database \"" << argv[4] << "\"" << endl;
    }
    else
    {
        cerr << "Unrecognized argument " << argv[1] << "\n    " 
             << argv[0] << " --help displays usage instructions." << endl;
        return EXIT_FAILURE;        
    }
    return EXIT_SUCCESS;
}
