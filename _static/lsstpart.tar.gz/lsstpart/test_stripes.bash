#! /usr/local/bin/bash
#
# ----------------------------------------------------------------
#
#   Script which performs LSST stripe based 
#   spatial partitioning tests.
#
#   The following scripts need to have been run
#   before the test can proceed:
#
#   prepare.bash            - loads USNO B test data
#   prepare_stripes.bash    - creates stripe based partition tables
#
# ----------------------------------------------------------------

set -e

# Ensure working directory is the script directory
cur_dir=`pwd`
script_dir=`dirname $0`
if test "X" = "X$script_dir" ; then
    script_dir=cur_dir
else
    cd $script_dir
    script_dir=`pwd`
fi
echo "Running from script directory: $script_dir"

if test "X" = "X$TEST_DB" ; then
    echo "Please set the TEST_DB environment variable to the"
    echo "name of the MySQL database you want to use for testing"
    echo "and rerun the script"
    exit 1
fi

if test "X" = "X$IOSTAT_PARMS" ; then
    echo "Warning: IOSTAT_PARMS environment variable is undefined or empty."
    echo "         By default, iostat will be run as 'iostat -cdx 1'."
    IOSTAT_PARMS="-cdx 1"
fi

if test "X" = "X$MPSTAT_PARMS" ; then
    echo "Warning: MPSTAT_PARMS environment variable is undefined or empty."
    echo "         By default, mpstat will be run as 'mp -p 1'."
    MPSTAT_PARMS="-p 1"
fi

# Setup log file to record what's going on
LOGFILE=../logs/test_stripes.log
rm -f $LOGFILE
touch $LOGFILE

# Load the test parameters
. test_regions.bash
. test_funs.bash

# Set maximum size of a MySQL in-memory table 
mysql -e "SET GLOBAL max_heap_table_size=8589934592;"

# ------------------------------------------------
# Function that runs a single load test (into a
# table with no indexes at all)
#
# Parameters
# 1,2,3  The names of the stripe tables to load data into memory from
# 4,5    The minimum,maximum dec of objects to load
# 6,7    The minimum,maximum ra of objects to load
# ------------------------------------------------
loadTest()
{
    SQL="DROP TABLE IF EXISTS InMemoryObject;
         CREATE TABLE InMemoryObject LIKE $1;
         ALTER TABLE InMemoryObject ADD COLUMN isDirty BOOL NOT NULL DEFAULT 0;
         ALTER TABLE InMemoryObject ENGINE = MEMORY;
         ALTER TABLE InMemoryObject CHANGE COLUMN id id BIGINT NOT NULL;
         ALTER TABLE InMemoryObject DROP PRIMARY KEY;
         ALTER TABLE InMemoryObject DROP INDEX idx_ra;
         ALTER TABLE InMemoryObject DROP INDEX idx_zone_ra;"

    mysql $TEST_DB -e "$SQL" >> $LOGFILE 2>&1

    # Setup WHERE clause. For now we include dec bounds to
    # cut down on the final size of InMemoryObject (but not
    # the disk read requirements)
    
    cmp=$(echo "if($6 > $7) 1" | bc)

    if [[ $cmp -eq 1 ]]
    then
        WHERE_CLAUSE="((ra >= $6) or (ra < $7))"
    else
        WHERE_CLAUSE="ra >= $6 and ra < $7"
    fi
    WHERE_CLAUSE="WHERE decl >= $4 and decl < $5 and $WHERE_CLAUSE"

    # empty MySQL server caches
    mysql $TEST_DB -e "FLUSH TABLES;" >> $LOGFILE 2>&1

    # NOTE: the inserts into the in-memory table are sequential. We could parallelize
    # by inserting into 3 different in-memory tables, and then creating a view that is
    # the union of all 3 tables. Whether or not this is a win (for read performance) 
    # really depends on the disk configuration. For example, if we can place separate
    # partitions on separate disk arrays, then this will likely give us a good speed up.
    # The impact on query performance is harder to measure since we don't know what
    # queries we'll be running. For now, keep this rabbit under our hats - we can
    # produce it later if needed.

    SQL="INSERT INTO InMemoryObject SELECT *,0 FROM $1 $WHERE_CLAUSE;
         INSERT INTO InMemoryObject SELECT *,0 FROM $2 $WHERE_CLAUSE;
         INSERT INTO InMemoryObject SELECT *,0 FROM $3 $WHERE_CLAUSE;"

    # start CPU, IO monitoring
    iostat $IOSTAT_PARMS >> $LOGFILE &
    IOSTAT_PID="$(jobs -p %%)"
    # run test
    (time mysql $TEST_DB -e "$SQL" ) >> $LOGFILE 2>&1
    #stop timer
    kill $IOSTAT_PID

    mysql $TEST_DB -e "SELECT count(*) FROM InMemoryObject" >> $LOGFILE 2>&1
}

# ------------------------------------------------
# Function that runs a single load test with
# indexes added before loading starts
#
# Parameters
# 1,2,3  The names of the stripe tables to load data into memory from
# 4,5    The minimum,maximum dec of objects to load
# 6,7    The minimum,maximum ra of objects to load
# ------------------------------------------------
loadAndIndexTest()
{
    SQL="DROP TABLE IF EXISTS InMemoryObject;
         CREATE TABLE InMemoryObject LIKE $1;
         ALTER TABLE InMemoryObject ADD COLUMN isDirty BOOL NOT NULL DEFAULT 0;
         ALTER TABLE InMemoryObject ENGINE = MEMORY;
         ALTER TABLE InMemoryObject CHANGE COLUMN id id BIGINT NOT NULL;
         ALTER TABLE InMemoryObject DROP INDEX idx_ra;
         ALTER TABLE InMemoryObject DROP INDEX idx_zone_ra;
         ALTER TABLE InMemoryObject ADD INDEX idx_zone_ra USING BTREE (zoneId, ra);"

    mysql $TEST_DB -e "$SQL" >> $LOGFILE 2>&1

    cmp=$(echo "if($6 > $7) 1" | bc)
    if [[ $cmp -eq 1 ]]
    then
        WHERE_CLAUSE="((ra >= $6) or (ra < $7))"
    else
        WHERE_CLAUSE="ra >= $6 and ra < $7"
    fi
    WHERE_CLAUSE="WHERE decl >= $4 and decl < $5 and $WHERE_CLAUSE"

    mysql $TEST_DB -e "FLUSH TABLES;" >> $LOGFILE 2>&1

    SQL="INSERT INTO InMemoryObject SELECT *,0 FROM $1 $WHERE_CLAUSE;
         INSERT INTO InMemoryObject SELECT *,0 FROM $2 $WHERE_CLAUSE;
         INSERT INTO InMemoryObject SELECT *,0 FROM $3 $WHERE_CLAUSE;"

    iostat $IOSTAT_PARMS >> $LOGFILE &
    IOSTAT_PID="$(jobs -p %%)"
    (time mysql $TEST_DB -e "$SQL" ) >> $LOGFILE 2>&1
    kill $IOSTAT_PID

    mysql $TEST_DB -e "SELECT count(*) FROM InMemoryObject" >> $LOGFILE 2>&1
}

# ------------------------------------------------
# Function that runs a single load test and
# then generates indexes
#
# Parameters
# 1,2,3  The names of the stripe tables to load data into memory from
# 4,5    The minimum,maximum dec of objects to load
# 6,7    The minimum,maximum ra of objects to load
# ------------------------------------------------
loadThenIndexTest()
{
    SQL="DROP TABLE IF EXISTS InMemoryObject;
         CREATE TABLE InMemoryObject LIKE $1;
         ALTER TABLE InMemoryObject ADD COLUMN isDirty BOOL NOT NULL DEFAULT 0;
         ALTER TABLE InMemoryObject ENGINE = MEMORY;
         ALTER TABLE InMemoryObject CHANGE COLUMN id id BIGINT NOT NULL;
         ALTER TABLE InMemoryObject DROP PRIMARY KEY;
         ALTER TABLE InMemoryObject DROP INDEX idx_ra;
         ALTER TABLE InMemoryObject DROP INDEX idx_zone_ra;"

    mysql $TEST_DB -e "$SQL" >> $LOGFILE 2>&1
    
    cmp=$(echo "if($6 > $7) 1" | bc)
    if [[ $cmp -eq 1 ]]
    then
        WHERE_CLAUSE="((ra >= $6) or (ra < $7))"
    else
        WHERE_CLAUSE="ra >= $6 and ra < $7"
    fi
    WHERE_CLAUSE="WHERE decl >= $4 and decl < $5 and $WHERE_CLAUSE"

    mysql $TEST_DB -e "FLUSH TABLES;" >> $LOGFILE 2>&1

    SQL="INSERT INTO InMemoryObject SELECT *,0 FROM $1 $WHERE_CLAUSE;
         INSERT INTO InMemoryObject SELECT *,0 FROM $2 $WHERE_CLAUSE;
         INSERT INTO InMemoryObject SELECT *,0 FROM $3 $WHERE_CLAUSE;
         ALTER TABLE InMemoryObject ADD PRIMARY KEY (id);
         ALTER TABLE InMemoryObject ADD INDEX idx_zone_ra USING BTREE (zoneId, ra);"

    iostat $IOSTAT_PARMS >> $LOGFILE &
    IOSTAT_PID="$(jobs -p %%)"
    (time mysql $TEST_DB -e "$SQL") >> $LOGFILE 2>&1
    kill $IOSTAT_PID

    mysql $TEST_DB -e "SELECT count(*) FROM InMemoryObject" >> $LOGFILE 2>&1
}



# ----------------------------------------------------------------
# 1. Run load tests for the different FOVs. Each test runs twice
#    (so the effect of OS caching can be observed)
# ----------------------------------------------------------------

# Try to flush the OS filesystem cache
bustcache /u1/usno_data/USNOcat.csv 16384 

cat >> $LOGFILE <<END_OF_CAT

         -----------------------------------------
        | Running load test on high density FOV ...
================================================================
END_OF_CAT

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadTest ObjStripe_HiA ObjStripe_HiB ObjStripe_HiC $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
loadTest ObjStripe_HiA ObjStripe_HiB ObjStripe_HiC $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadTest ObjStripe_HiFatA ObjStripe_HiFatB ObjStripe_HiFatC $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
loadTest ObjStripe_HiFatA ObjStripe_HiFatB ObjStripe_HiFatC $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

cat >> $LOGFILE <<END_OF_CAT

         -----------------------------------------
        | Running load test on low density FOV ...
================================================================
END_OF_CAT

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadTest ObjStripe_LoA ObjStripe_LoB ObjStripe_LoC $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
loadTest ObjStripe_LoA ObjStripe_LoB ObjStripe_LoC $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadTest ObjStripe_LoFatA ObjStripe_LoFatB ObjStripe_LoFatC $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
loadTest ObjStripe_LoFatA ObjStripe_LoFatB ObjStripe_LoFatC $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

cat >> $LOGFILE <<END_OF_CAT

         -----------------------------------------
        | Running load test on average density FOV ...
================================================================
END_OF_CAT

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadTest ObjStripe_AvgA ObjStripe_AvgB ObjStripe_AvgC $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
loadTest ObjStripe_AvgA ObjStripe_AvgB ObjStripe_AvgC $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadTest ObjStripe_AvgFatA ObjStripe_AvgFatB ObjStripe_AvgFatC $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
loadTest ObjStripe_AvgFatA ObjStripe_AvgFatB ObjStripe_AvgFatC $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 2. Run load-and-index test for the different FOVs. 
# ----------------------------------------------------------------

# Try to flush the OS filesystem cache
bustcache /u1/usno_data/USNOcat.csv 16384 

cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------------------
        | Running load-and-index test on high density FOV ...
================================================================
END_OF_CAT

setupForWrites $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadAndIndexTest ObjStripe_HiA ObjStripe_HiB ObjStripe_HiC $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
xmatch
loadAndIndexTest ObjStripe_HiA ObjStripe_HiB ObjStripe_HiC $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
wxmatch "WideLooseMatch"

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadAndIndexTest ObjStripe_HiFatA ObjStripe_HiFatB ObjStripe_HiFatC $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
xmatch
loadAndIndexTest ObjStripe_HiFatA ObjStripe_HiFatB ObjStripe_HiFatC $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
wxmatch "WideFatLooseMatch"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

cat >> $LOGFILE <<END_OF_CAT

         ---------------------------------------------------
        | Running load-and-index test on low density FOV ...
================================================================
END_OF_CAT

setupForWrites $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadAndIndexTest ObjStripe_LoA ObjStripe_LoB ObjStripe_LoC $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
xmatch
loadAndIndexTest ObjStripe_LoA ObjStripe_LoB ObjStripe_LoC $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
wxmatch "WideLooseMatch"

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadAndIndexTest ObjStripe_LoFatA ObjStripe_LoFatB ObjStripe_LoFatC $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
xmatch
loadAndIndexTest ObjStripe_LoFatA ObjStripe_LoFatB ObjStripe_LoFatC $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
wxmatch "WideFatLooseMatch"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

cat >> $LOGFILE <<END_OF_CAT

         --------------------------------------------------------
        | Running load-and-index test on average density FOV ...
=================================================================
END_OF_CAT

setupForWrites $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadAndIndexTest ObjStripe_AvgA ObjStripe_AvgB ObjStripe_AvgC $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
xmatch
loadAndIndexTest ObjStripe_AvgA ObjStripe_AvgB ObjStripe_AvgC $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
wxmatch "WideLooseMatch"

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadAndIndexTest ObjStripe_AvgFatA ObjStripe_AvgFatB ObjStripe_AvgFatC $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
xmatch
loadAndIndexTest ObjStripe_AvgFatA ObjStripe_AvgFatB ObjStripe_AvgFatC $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
wxmatch "WideFatLooseMatch"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 3. Run load-then-index test for the different FOVs. 
# ----------------------------------------------------------------

# Try to flush the OS filesystem cache
bustcache /u1/usno_data/USNOcat.csv 16384 

cat >> $LOGFILE <<END_OF_CAT

         -----------------------------------------------------
        | Running load-then-index test on high density FOV ...
================================================================
END_OF_CAT

setupForWrites $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadThenIndexTest ObjStripe_HiA ObjStripe_HiB ObjStripe_HiC $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
xmatch
loadThenIndexTest ObjStripe_HiA ObjStripe_HiB ObjStripe_HiC $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
wxmatch "WideLooseMatch"

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadThenIndexTest ObjStripe_HiFatA ObjStripe_HiFatB ObjStripe_HiFatC $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
xmatch
loadThenIndexTest ObjStripe_HiFatA ObjStripe_HiFatB ObjStripe_HiFatC $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
wxmatch "WideFatLooseMatch"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------------------
        | Running load-then-index test on low density FOV ...
================================================================
END_OF_CAT

setupForWrites $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadThenIndexTest ObjStripe_LoA ObjStripe_LoB ObjStripe_LoC $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
xmatch
loadThenIndexTest ObjStripe_LoA ObjStripe_LoB ObjStripe_LoC $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
wxmatch "WideLooseMatch"

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadThenIndexTest ObjStripe_LoFatA ObjStripe_LoFatB ObjStripe_LoFatC $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
xmatch
loadThenIndexTest ObjStripe_LoFatA ObjStripe_LoFatB ObjStripe_LoFatC $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
wxmatch "WideFatLooseMatch"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

cat >> $LOGFILE <<END_OF_CAT

         --------------------------------------------------------
        | Running load-then-index test on average density FOV ...
=================================================================
END_OF_CAT

setupForWrites $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadThenIndexTest ObjStripe_AvgA ObjStripe_AvgB ObjStripe_AvgC $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
xmatch
loadThenIndexTest ObjStripe_AvgA ObjStripe_AvgB ObjStripe_AvgC $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
wxmatch "WideLooseMatch"

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadThenIndexTest ObjStripe_AvgFatA ObjStripe_AvgFatB ObjStripe_AvgFatC $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
xmatch
loadThenIndexTest ObjStripe_AvgFatA ObjStripe_AvgFatB ObjStripe_AvgFatC $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
wxmatch "WideFatLooseMatch"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

# cleanup
mysql $TEST_DB -e "DROP TABLE WideLooseMatch; DROP TABLE WideFatLooseMatch;"