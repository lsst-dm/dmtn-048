#! /usr/local/bin/bash
#
# ----------------------------------------------------------------
#
#   Script which performs LSST chunk based 
#   spatial partitioning tests.
#
#   The following scripts need to have been run
#   before the test can proceed:
#
#   prepare.bash            - loads USNO B test data
#   prepare_chunks.bash     - creates chunk based partition tables
#
# ----------------------------------------------------------------

set -e

# Ensure working directory is the script directory
cur_dir=`pwd`
script_dir=`dirname $0`
if test "X" = "X$script_dir" ; then
    script_dir=cur_dir
else
    cd $script_dir
    script_dir=`pwd`
fi
echo "Running from script directory: $script_dir"

if test "X" = "X$TEST_DB" ; then
    echo "Please set the TEST_DB environment variable to the"
    echo "name of the MySQL database you want to use for testing"
    echo "and rerun the script"
    exit 1
fi

if test "X" = "X$IOSTAT_PARMS" ; then
    echo "Warning: IOSTAT_PARMS environment variable is undefined or empty."
    echo "         By default, iostat will be run as 'iostat -cdx 1'."
    IOSTAT_PARMS="-cdx 1"
fi

if test "X" = "X$MPSTAT_PARMS" ; then
    echo "Warning: MPSTAT_PARMS environment variable is undefined or empty."
    echo "         By default, mpstat will be run as 'mp -p 1'."
    MPSTAT_PARMS="-p 1"
fi

# Setup log file to record what's going on
LOGFILE=../logs/test_chunks.log
rm -f $LOGFILE
touch $LOGFILE

# Load the test parameters
. test_regions.bash
. test_funs.bash

# Set maximum size of a MySQL in-memory table 
mysql -e "SET GLOBAL max_heap_table_size=8589934592;"

# ------------------------------------------------
# Function that runs a single load test (into a
# table with no indexes at all)
#
# Parameters
# 1      An array of chunk table names to load data into memory from
# 2,3    The minimum,maximum dec of objects to load
# 4,5    The minimum,maximum ra of objects to load
# ------------------------------------------------
loadTest()
{
    tables=($1)
    SQL="DROP TABLE IF EXISTS InMemoryObject;
         CREATE TABLE InMemoryObject LIKE ${tables[0]};
         ALTER TABLE InMemoryObject ENGINE = MEMORY;         
         ALTER TABLE InMemoryObject ADD COLUMN isDirty BOOL NOT NULL DEFAULT 0;"

     mysql $TEST_DB -e "$SQL" >> $LOGFILE 2>&1

    # Setup WHERE clause. Include dec bounds to cut
    # down on the final size of InMemoryObject, if
    # not the data read requirements.

    cmp=$(echo "if($4 > $5) 1" | bc)
    if [[ $cmp -eq 1 ]]
    then
        WHERE_CLAUSE="((ra >= $4) or (ra < $5))"
    else
        WHERE_CLAUSE="ra >= $4 and ra < $5"
    fi
    WHERE_CLAUSE="WHERE decl >= $2 and decl < $3 and $WHERE_CLAUSE"

    # empty MySQL server caches
    mysql $TEST_DB -e "FLUSH TABLES;" >> $LOGFILE 2>&1

    # construct a series of sequential insert statements
    SQL=""
    for table in $1
    do
       SQL="$SQL INSERT INTO InMemoryObject SELECT *,0 FROM $table $WHERE_CLAUSE;"
    done

    # NOTE: the inserts into the in-memory table are sequential. We could parallelize
    # by inserting into N different in-memory tables, and then creating a view that is
    # the union of all N tables. Whether or not this is a win (for read performance)
    # really depends on the disk configuration. For example, if we can place separate
    # chunks on separate disks, then this will likely give us a very good speed up.
    # The impact on query performance is harder to measure since we don't know what
    # queries we'll be running. For now, keep this rabbit under our hats - we can
    # produce it later if needed.

    #start timer, CPU, IO monitoring
    iostat $IOSTAT_PARMS >> $LOGFILE &
    IOSTAT_PID="$(jobs -p %%)"
    # run test
    (time mysql $TEST_DB -e "$SQL" ) >> $LOGFILE 2>&1
    #stop timer
    kill $IOSTAT_PID

    mysql $TEST_DB -e "SELECT count(*) FROM InMemoryObject" >> $LOGFILE 2>&1
}

# ------------------------------------------------
# Function that runs a single load test with
# indexes added before loading starts
#
# Parameters
# 1      An array of chunk table names to load data into memory from
# 4,5    The minimum,maximum dec of objects to load
# 6,7    The minimum,maximum ra of objects to load
# ------------------------------------------------
loadAndIndexTest()
{
    tables=($1)
    SQL="DROP TABLE IF EXISTS InMemoryObject;
         CREATE TABLE InMemoryObject LIKE ${tables[0]};
         ALTER TABLE InMemoryObject ENGINE = MEMORY;
         ALTER TABLE InMemoryObject ADD COLUMN isDirty BOOL NOT NULL DEFAULT 0;
         ALTER TABLE InMemoryObject ADD PRIMARY KEY (id);
         ALTER TABLE InMemoryObject ADD INDEX idx_zone_ra USING BTREE (zoneId, ra);"

    mysql $TEST_DB -e "$SQL" >> $LOGFILE 2>&1

    cmp=$(echo "if($4 > $5) 1" | bc)
    if [[ $cmp -eq 1 ]]
    then
        WHERE_CLAUSE="((ra >= $4) or (ra < $5))"
    else
        WHERE_CLAUSE="ra >= $4 and ra < $5"
    fi
    WHERE_CLAUSE="WHERE decl >= $2 and decl < $3 and $WHERE_CLAUSE"

    mysql $TEST_DB -e "FLUSH TABLES;" >> $LOGFILE 2>&1

    SQL=""
    for table in $1
    do
       SQL="$SQL INSERT INTO InMemoryObject SELECT *,0 FROM $table $WHERE_CLAUSE;"
    done

    iostat $IOSTAT_PARMS >> $LOGFILE &
    IOSTAT_PID="$(jobs -p %%)"
    (time mysql $TEST_DB -e "$SQL" ) >> $LOGFILE 2>&1
    kill $IOSTAT_PID

    mysql $TEST_DB -e "SELECT count(*) FROM InMemoryObject" >> $LOGFILE 2>&1
}

# ------------------------------------------------
# Function that runs a single load test and
# then generates indexes
#
# Parameters
# 1      An array of chunk table names to load data into memory from
# 4,5    The minimum,maximum dec of objects to load
# 6,7    The minimum,maximum ra of objects to load
# ------------------------------------------------
loadThenIndexTest()
{
    tables=($1)
    SQL="DROP TABLE IF EXISTS InMemoryObject;
         CREATE TABLE InMemoryObject LIKE ${tables[0]};
         ALTER TABLE InMemoryObject ENGINE = MEMORY;
         ALTER TABLE InMemoryObject ADD COLUMN isDirty BOOL NOT NULL DEFAULT 0;"
    mysql $TEST_DB -e "$SQL" >> $LOGFILE 2>&1
    
    cmp=$(echo "if($4 > $5) 1" | bc)
    if [[ $cmp -eq 1 ]]
    then
        WHERE_CLAUSE="((ra >= $4) or (ra < $5))"
    else
        WHERE_CLAUSE="ra >= $4 and ra < $5"
    fi
    WHERE_CLAUSE="WHERE decl >= $2 and decl < $3 and $WHERE_CLAUSE"

    mysql $TEST_DB -e "FLUSH TABLES;" >> $LOGFILE 2>&1

    SQL=""
    for table in $1 
    do
       SQL="$SQL INSERT INTO InMemoryObject SELECT *,0 FROM $table $WHERE_CLAUSE;"
    done
    SQL="$SQL ALTER TABLE InMemoryObject ADD PRIMARY KEY (id);
         ALTER TABLE InMemoryObject ADD INDEX idx_zone_ra USING BTREE (zoneId, ra);"

    iostat $IOSTAT_PARMS >> $LOGFILE &
    IOSTAT_PID="$(jobs -p %%)"
    (time mysql $TEST_DB -e "$SQL") >> $LOGFILE 2>&1
    kill $IOSTAT_PID

    mysql $TEST_DB -e "SELECT count(*) FROM InMemoryObject" >> $LOGFILE 2>&1
}


# ----------------------------------------------------------------
# 1. Get chunk ID lists for test regions and generate
#    test table names
# ----------------------------------------------------------------

HI_CHUNKS=` chunkgen 10800 105 $HI_DEC_MIN  $HI_DEC_MAX  $HI_RA_MIN  $HI_RA_MAX`
LO_CHUNKS=` chunkgen 10800 105 $LO_DEC_MIN  $LO_DEC_MAX  $LO_RA_MIN  $LO_RA_MAX`
AVG_CHUNKS=`chunkgen 10800 105 $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX`

HI_TABLES=""
HIFAT_TABLES=""
LO_TABLES=""
LOFAT_TABLES=""
AVG_TABLES=""
AVGFAT_TABLES=""

for i in $HI_CHUNKS
do
    HI_TABLES="$HI_TABLES ChHi_1_$i"
    HIFAT_TABLES="$HIFAT_TABLES ChHiFat_1_$i"
done
for i in $LO_CHUNKS
do
    LO_TABLES="$LO_TABLES ChLo_1_$i"
    LOFAT_TABLES="$LOFAT_TABLES ChLoFat_1_$i"
done
for i in $AVG_CHUNKS
do
    AVG_TABLES="$AVG_TABLES ChAvg_1_$i"
    AVGFAT_TABLES="$AVGFAT_TABLES ChAvgFat_1_$i"
done




# ----------------------------------------------------------------
# 2. Run load tests for the different FOVs. Each test runs twice
#    (so the effect of OS caching can be observed)
# ----------------------------------------------------------------

# Try to flush the OS filesystem cache
bustcache /u1/usno_data/USNOcat.csv 16384 

cat >> $LOGFILE <<END_OF_CAT

         ------------------------------------------
        | Running load test on high density FOV ...
================================================================
END_OF_CAT

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadTest "$HI_TABLES" $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
loadTest "$HI_TABLES" $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadTest "$HIFAT_TABLES" $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
loadTest "$HIFAT_TABLES" $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

cat >> $LOGFILE <<END_OF_CAT

         -----------------------------------------
        | Running load test on low density FOV ...
================================================================
END_OF_CAT

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadTest "$LO_TABLES" $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
loadTest "$LO_TABLES" $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadTest "$LOFAT_TABLES" $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
loadTest "$LOFAT_TABLES" $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

cat >> $LOGFILE <<END_OF_CAT

         ---------------------------------------------
        | Running load test on average density FOV ...
================================================================
END_OF_CAT

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadTest "$AVG_TABLES" $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
loadTest "$AVG_TABLES" $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadTest "$AVGFAT_TABLES" $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
loadTest "$AVGFAT_TABLES" $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 3. Run load-and-index test for the different FOVs. 
# ----------------------------------------------------------------

# Try to flush the OS filesystem cache
bustcache /u1/usno_data/USNOcat.csv 16384 

cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------------------
        | Running load-and-index test on high density FOV ...
================================================================
END_OF_CAT

setupForWrites $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadAndIndexTest "$HI_TABLES" $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
xmatch
loadAndIndexTest "$HI_TABLES" $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
wxmatch "WideLooseMatch"

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadAndIndexTest "$HIFAT_TABLES" $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
xmatch
loadAndIndexTest "$HIFAT_TABLES" $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
wxmatch "WideFatLooseMatch"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

cat >> $LOGFILE <<END_OF_CAT

         ---------------------------------------------------
        | Running load-and-index test on low density FOV ...
================================================================
END_OF_CAT

setupForWrites $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadAndIndexTest "$LO_TABLES" $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
xmatch
loadAndIndexTest "$LO_TABLES" $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
wxmatch "WideLooseMatch"

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadAndIndexTest "$LOFAT_TABLES" $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
xmatch
loadAndIndexTest "$LOFAT_TABLES" $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
wxmatch "WideFatLooseMatch"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

cat >> $LOGFILE <<END_OF_CAT

         -------------------------------------------------------
        | Running load-and-index test on average density FOV ...
================================================================
END_OF_CAT

setupForWrites $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadAndIndexTest "$AVG_TABLES" $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
xmatch
loadAndIndexTest "$AVG_TABLES" $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
wxmatch "WideLooseMatch"

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadAndIndexTest "$AVGFAT_TABLES" $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
xmatch
loadAndIndexTest "$AVGFAT_TABLES" $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
wxmatch "WideFatLooseMatch"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT





# ----------------------------------------------------------------
# 4. Run load-then-index test for the different FOVs. 
# ----------------------------------------------------------------

# Try to flush the OS filesystem cache
bustcache /u1/usno_data/USNOcat.csv 16384 

cat >> $LOGFILE <<END_OF_CAT

         -----------------------------------------------------
        | Running load-then-index test on high density FOV ...
================================================================
END_OF_CAT

setupForWrites $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadThenIndexTest "$HI_TABLES" $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
xmatch
loadThenIndexTest "$HI_TABLES" $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
wxmatch "WideLooseMatch"

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadThenIndexTest "$HIFAT_TABLES" $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
xmatch
loadThenIndexTest "$HIFAT_TABLES" $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX
wxmatch "WideFatLooseMatch"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------------------
        | Running load-then-index test on low density FOV ...
================================================================
END_OF_CAT

setupForWrites $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadThenIndexTest "$LO_TABLES" $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
xmatch
loadThenIndexTest "$LO_TABLES" $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
wxmatch "WideLooseMatch"

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadThenIndexTest "$LOFAT_TABLES" $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
xmatch
loadThenIndexTest "$LOFAT_TABLES" $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX
wxmatch "WideFatLooseMatch"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

cat >> $LOGFILE <<END_OF_CAT

         --------------------------------------------------------
        | Running load-then-index test on average density FOV ...
=================================================================
END_OF_CAT

setupForWrites $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadThenIndexTest "$AVG_TABLES" $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
xmatch
loadThenIndexTest "$AVG_TABLES" $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
wxmatch "WideLooseMatch"

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadThenIndexTest "$AVGFAT_TABLES" $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
xmatch
loadThenIndexTest "$AVGFAT_TABLES" $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX
wxmatch "WideFatLooseMatch"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

# cleanup
mysql $TEST_DB -e "DROP TABLE WideLooseMatch; DROP TABLE WideFatLooseMatch;"
