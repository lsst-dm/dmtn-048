#! /usr/local/bin/bash
#
# ----------------------------------------------------------------
#
#   Script which performs common set up steps for all
#   LSST spatial partitioning tests
#
# ----------------------------------------------------------------

set -e

# Ensure working directory is the script directory
cur_dir=`pwd`
script_dir=`dirname $0`
if test "X" = "X$script_dir" ; then
    script_dir=cur_dir
else
    cd $script_dir
    script_dir=`pwd`
fi
echo "Running from script directory: $script_dir"

if test "X" = "X$TEST_DB" ; then
    echo "Please set the TEST_DB environment variable to the"
    echo "name of the MySQL database you want to use for testing"
    echo "and rerun the script"
    exit 1
fi

if test "X" = "X$IOSTAT_PARMS" ; then
    echo "Note: IOSTAT_PARMS environment variable is undefined or empty."
    echo "      By default, iostat will be run as 'iostat -cdx 60'."
    IOSTAT_PARMS="-cdx 60"
fi

# Ensure required directories exist ...
mkdir -p ../gen
mkdir -p ../logs

# Setup log file to record what's going on
LOGFILE=../logs/prepare.log
rm -f $LOGFILE
touch $LOGFILE




# ----------------------------------------------------------------
# 1. Install schema
#
#    Note that the fat object table for which the schema is
#    generated below will never contain any data, it's just
#    a template used to create much smaller "fat" tables for
#    individual chunks/stripes
#
# ----------------------------------------------------------------

cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------
        | Installing usno_test schema ...
================================================================
END_OF_CAT

( cd ../gen; ../lsstpart/genFatObjectFiles.py; )
mysql $TEST_DB < schema.sql >> $LOGFILE 2>&1
mysql $TEST_DB < ../gen/fat.sql >> $LOGFILE 2>&1


cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 2. Load usno data to a single table
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------
        | Loading original USNO data:
        | $TIMESTAMP ...
================================================================

END_OF_CAT

# disable indexes on Object table
mysql $TEST_DB -e "ALTER TABLE Object DISABLE KEYS" >> $LOGFILE 2>&1

# spawn an iostat background job to keep tabs on disk and CPU perf
iostat $IOSTAT_PARMS >> $LOGFILE &

# get the iostat job pid
IOSTAT_PID="$(jobs -p %%)"

# load the data (and time it)
( time mysql $TEST_DB -e "LOAD DATA LOCAL INFILE '/u1/usno_data/USNOcat.csv' INTO TABLE Object FIELDS TERMINATED BY ',' IGNORE 1 LINES (ra, decl, pm_ra, pm_raErr, pm_decl, pm_decErr, epoch, bMag, bErr, rMag, rErr, bMag2, bErr2, rMag2, rErr2)" ) >> $LOGFILE 2>&1

# kill the iostat job (otherwise it will never exit)
kill $IOSTAT_PID

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 3. Calculate unit sphere coords (x,y,z) and zoneId, stripeId
#
#    We don't actually need x,y,z for the current tests. However,
#    X-match will require them, so compute them now.
#
#    Note the following hardcoded zone/stripe heights:
#    zone height   : 60.00 arcseconds (60*180 = 10,800 zones total)
#    stripe height :  1.75 degrees    (105 zones per stripe)
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         -------------------------------------------------
        | Updating USNO table - setting
        | x, y, z, zoneId, stripeId, fineStripeId:
        | $TIMESTAMP ...
================================================================

END_OF_CAT

iostat $IOSTAT_PARMS >> $LOGFILE &
IOSTAT_PID="$(jobs -p %%)"

SQL="UPDATE Object
       SET x = cos(RADIANS(ra))*cos(RADIANS(decl)),
           y = sin(RADIANS(ra))*cos(RADIANS(decl)),
           z = sin(RADIANS(decl)),
           zoneId       = IF(5399 < floor(decl*60), 5399, floor(decl*60)),
           stripeId     = floor(IF(5399 < floor(decl*60), 5399, floor(decl*60))/105),
           fineStripeId = floor(IF(5399 < floor(decl*60), 5399, floor(decl*60))/21);"

( time mysql $TEST_DB -e "$SQL" ) >> $LOGFILE 2>&1

# Note: use zoneId to compute stripeId and fineStripeId since otherwise numerical
# inaccuracy could cause a position to be assigned to a stripe that doesn't
# contain the zone the position was assigned to.

kill $IOSTAT_PID

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 4. Generate/load stripes and chunks table, calculate chunkId
#
#    Note that the tests don't make much use of the ObjectStripes
#    and ObjectChunks tables - they serve mostly to make the
#    stripe/chunk descriptions explicit.
#
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         -----------------------------------------
        | Generating stripes, chunks; 
        | setting chunkId and fineChunkId:
        | $TIMESTAMP ...
================================================================

END_OF_CAT

cd ../gen

/bin/echo "\nGenerating fineChunks.csv and fineStripes.csv ..." >> $LOGFILE
( time ../lsstpart/chunkgen 10800 21; ) >> $LOGFILE 2>&1
mv stripes.csv fineStripes.csv
mv chunks.csv fineChunks.csv
/bin/echo "\nLoading fine stripes table ... " >> $LOGFILE
( time mysql $TEST_DB -e "LOAD DATA LOCAL INFILE '$PWD/fineStripes.csv' INTO TABLE ObjectFineStripes FIELDS TERMINATED BY ',' IGNORE 3 LINES (stripeId, numChunks, decMin, decMax)" ) >> $LOGFILE 2>&1
/bin/echo "\nLoading fine chunks table ... \n" >> $LOGFILE
( time mysql $TEST_DB -e "LOAD DATA LOCAL INFILE '$PWD/fineChunks.csv' INTO TABLE ObjectFineChunks FIELDS TERMINATED BY ',' IGNORE 3 LINES (chunkId, stripeId, raMin, raMax, decMin, decMax)" ) >> $LOGFILE 2>&1

/bin/echo "\nGenerating chunks.csv and stripes.csv ..." >> $LOGFILE
( time ../lsstpart/chunkgen 10800 105; ) >> $LOGFILE 2>&1
/bin/echo "\nLoading stripes table ... " >> $LOGFILE
( time mysql $TEST_DB -e "LOAD DATA LOCAL INFILE '$PWD/stripes.csv' INTO TABLE ObjectStripes FIELDS TERMINATED BY ',' IGNORE 3 LINES (stripeId, numChunks, decMin, decMax)" ) >> $LOGFILE 2>&1
/bin/echo "\nLoading chunks table ... \n" >> $LOGFILE
( time mysql $TEST_DB -e "LOAD DATA LOCAL INFILE '$PWD/chunks.csv' INTO TABLE ObjectChunks FIELDS TERMINATED BY ',' IGNORE 3 LINES (chunkId, stripeId, raMin, raMax, decMin, decMax)" ) >> $LOGFILE 2>&1

/bin/echo "\nSetting chunkId, fineChunkId for each Object ...\n" >> $LOGFILE 

iostat $IOSTAT_PARMS >> $LOGFILE &
IOSTAT_PID="$(jobs -p %%)"

# Update Object table with chunkId and fineChunkId per object
SQL="UPDATE Object AS o
       INNER JOIN ObjectStripes AS s ON o.stripeId = s.stripeId
       INNER JOIN ObjectFineStripes AS fs ON o.fineStripeId = fs.stripeId
       SET o.chunkId     = (o.stripeId     +  52)*205  + (floor((o.ra* s.numChunks)/360) %  s.numChunks),
           o.fineChunkId = (o.fineStripeId + 258)*1028 + (floor((o.ra*fs.numChunks)/360) % fs.numChunks);"

( time mysql $TEST_DB -e "$SQL" ) >> $LOGFILE 2>&1;

kill $IOSTAT_PID


/bin/echo "\n\nSpatial information calculated ... enabling indexes:\n\n" >> $LOGFILE

# enable indexes (and time it)
iostat $IOSTAT_PARMS >> $LOGFILE &
IOSTAT_PID="$(jobs -p %%)"

(time mysql $TEST_DB -e "ALTER TABLE Object ENABLE KEYS" ) >> $LOGFILE 2>&1

kill $IOSTAT_PID


# Note : Attempting to cluster the data at this point is a no go -
# myisamchk ran for several days ... I gave up.
#
#echo "Clustering Object table spatially ..." >> $LOGFILE
#
#iostat $IOSTAT_PARMS >> $LOGFILE &
#IOSTAT_PID="$(jobs -p %%)"
#
# Index 1 is the PK, 2 is the spatial index 
#( cd /u2/mysql_data/$TEST_DB/; \
#  time myisamchk --sort-records=2 --sort-index Object; \
#  chgrp mysql Object.MYI Object.MYD; ) >> $LOGFILE 2>&1
#
#kill $IOSTAT_PID

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT


# ----------------------------------------------------------------
# 6. Find object distribution per stripe and per chunk
#
#    This is the last step in the global prepare script - it 
#    produces that object distribution histograms used to pick
#    the stripes/chunks to actually run tests on (each test
#    will be run on a high, average, and low density partition
#    with skinny and fat rows).
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------
        | Finding object distribution:
        | $TIMESTAMP ...
================================================================

END_OF_CAT

rm -f /tmp/stripeDistribution.csv
rm -f /tmp/chunkDistribution.csv

iostat $IOSTAT_PARMS >> $LOGFILE &
IOSTAT_PID="$(jobs -p %%)"

( time mysql $TEST_DB < ../lsstpart/distribution.sql ) >> $LOGFILE 2>&1

kill $IOSTAT_PID

cp -f /tmp/stripeDistribution.csv .
cp -f /tmp/chunkDistribution.csv .

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT

