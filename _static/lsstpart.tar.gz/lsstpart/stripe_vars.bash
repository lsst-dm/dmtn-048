#! /usr/local/bin/bash
#
# ----------------------------------------------------------------
#  List of table names and stripe IDs for those tables 
#  used in stripe/zone spatial partitioning tests.
# ----------------------------------------------------------------

# A list of skinny table names (order is important)
SKINNY_TABLES="ObjStripe_HiA
ObjStripe_HiB
ObjStripe_HiC
ObjStripe_LoA
ObjStripe_LoB
ObjStripe_LoC
ObjStripe_AvgA
ObjStripe_AvgB
ObjStripe_AvgC"

# A list of fat table names (order is important)
FAT_TABLES="ObjStripe_HiFatA
ObjStripe_HiFatB
ObjStripe_HiFatC
ObjStripe_LoFatA
ObjStripe_LoFatB
ObjStripe_LoFatC
ObjStripe_AvgFatA
ObjStripe_AvgFatB
ObjStripe_AvgFatC"

# Stripe IDs, one for each skinny/fat table pair
STRIPE_IDS[0]=-17     # for HiA,  HiFatA
STRIPE_IDS[1]=-16     # for HiB,  HiFatB
STRIPE_IDS[2]=-15     # for HiC,  HiFatC

STRIPE_IDS[3]=-2      # for LoA,  LoFatA
STRIPE_IDS[4]=-1      # for LoB,  LoFatB
STRIPE_IDS[5]=0       # for LoC,  LoFatC

STRIPE_IDS[6]=31      # for AvgA, AvgFatA
STRIPE_IDS[7]=32      # for AvgB, AvgFatB
STRIPE_IDS[8]=33      # for AvgC, AvgFatC

# Stripe IDs converted to ranges [min, max) of fine stripe  IDs
# (useful if Object is indexed spatially)
STRIPE_MIN[0]=-85     # for HiA,  HiFatA
STRIPE_MIN[1]=-80     # for HiB,  HiFatB
STRIPE_MIN[2]=-75     # for HiC,  HiFatC
              
STRIPE_MIN[3]=-10     # for LoA,  LoFatA
STRIPE_MIN[4]=-5      # for LoB,  LoFatB
STRIPE_MIN[5]=0       # for LoC,  LoFatC
                 
STRIPE_MIN[6]=155     # for AvgA, AvgFatA
STRIPE_MIN[7]=160     # for AvgB, AvgFatB
STRIPE_MIN[8]=165     # for AvgC, AvgFatC
              
STRIPE_MAX[0]=-80     # for HiA,  HiFatA
STRIPE_MAX[1]=-75     # for HiB,  HiFatB
STRIPE_MAX[2]=-70     # for HiC,  HiFatC
                 
STRIPE_MAX[3]=-5      # for LoA,  LoFatA
STRIPE_MAX[4]=0       # for LoB,  LoFatB
STRIPE_MAX[5]=5       # for LoC,  LoFatC
                 
STRIPE_MAX[6]=160     # for AvgA, AvgFatA
STRIPE_MAX[7]=165     # for AvgB, AvgFatB
STRIPE_MAX[8]=170     # for AvgC, AvgFatC
