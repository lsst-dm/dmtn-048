/*!
    \file       chunkgen.cpp
    \brief      Generate CSV tables corresponding to constant height dec 
                stripes and constant width (per-stripe) ra chunks.
                
                To be used for LSST partitioning strategy tests.

    \author     Serge Monkewitz
 */
#include <exception>
#include <vector>
#include <iostream>
#include <sstream>
#include <fstream>

#include <cstdlib>
#include <cstring>
#include <cmath>


/*! Global constants */
const double gRadPerDeg = 0.017453292519943295769236907684886;
const double gTwoPi     = 6.283185307179586476925286766559;

/*! Prints usage directions for the program to standard out. */
void printUsage(char const * const progName)
{
using namespace std;

    cout << 
        "\nUsage: " << progName << " --help\n\n"
        "  Prints out program usage information\n\n";

    cout <<
        "    " << progName << " <stripe_height>\n\n"
        "  Writes 2 CSV tables, stripes.csv and chunks.csv, to the current\n"
        "  working directory. stripes.csv contains 1 row describing each dec\n"
        "  stripe, and chunks.csv 1 row for each chunk of each stripe. Each\n"
        "  stripe will be <stripe_height> arc-seconds high, except for the two\n"
        "  stripes containing the north and south poles. Each stripe is\n"
        "  then subdivided into chunks that are at least <stripe_height> arc-\n"
        "  seconds wide.\n\n";

    cout <<
        "    " << progName << " <num_zones> <zones_per_stripe>\n\n"
        "  Generates the same tables as above, but determines the height of\n"
        "  a stripe (and the minimum width of a chunk) by first partitioning\n"
        "  the unit sphere into <num_zones> zones and then grouping together\n"
        "  <zones_per_stripe> adjacent zones to form a stripe.\n\n";

    cout <<
        "    " << progName << " (<num_zones> <zones_per_stripe> | <stripe_height>)\n"
        "             <dec_min> <dec_max>\n\n"
        "  Prints a list of stripes overlapping the specified dec range to\n"
        "  standard out. One stripe ID is printed per line, all angles are\n"
        "  assumed to be in degrees. Stripes are generated as above, but are\n"
        "  not saved to a file.\n" << endl;

    cout <<
        "    " << progName << " (<num_zones> <zones_per_stripe> | <stripe_height>)\n"
        "             <dec_min> <dec_max> <ra_min> <ra_max>\n\n"
        "  Prints a list of chunks overlapping the specified ra/dec box to\n"
        "  standard out. One chunk ID is printed per line, all angles are\n"
        "  assumed to be in degrees. Stripes and chunks are generated as\n"
        "  above, but are not saved to files.\n" << endl;
}

/*! An ra/dec box. */
struct Box
{
    double _raMin;
    double _raMax;
    double _decMin;
    double _decMax;
};


/*! Description of a declination stripe */
class DecStripe
{
    double _decMin;      //!< The min declination (inclusive) within the stripe
    double _decMax;      //!< The max declination (exclusive) within the stripe
    int    _stripeId;    //!< An id for the stripe
    int    _numChunks;   //!< The number of chunks to partition the stripe into

public :

    DecStripe() : _decMin(0.0), _decMax(0.0), _stripeId(0), _numChunks(0) {}
    
    DecStripe(double const min, double const max, double const height, int const id) :
        _decMin(min),
        _decMax(max),
        _stripeId(id),
        _numChunks(chunksPerStripe(height, min, max)) 
    {
        // dec min is inclusive, dec max is exclusive. Since dec has no wrapping 
        // issues and a source can have dec exactly +-90, pad a little
        if (_decMax >= 90.)
            _decMax = 90.01;
    }
    
    ~DecStripe() {}
    
    DecStripe& mirror()
    {
        double d  = - _decMin;
        _decMin   = - _decMax;
        _decMax   = d;
        _stripeId = -1 - _stripeId;
        return *this;
    }
    
    void setId(int const id)
    {
        _stripeId = id;
    }
    
    double getDecMin() const    { return _decMin;    }
    double getDecMax() const    { return _decMax;    }
    double getId() const        { return _stripeId;  }
    double getNumChunks() const { return _numChunks; }
    
    void writeChunks(std::ostream & os, 
                     int const      maxChunksPerStripe,
                     int const      stripesPerHemi) const
    {
        if (_numChunks <= 1)
        {
            os << ((_stripeId + stripesPerHemi)*maxChunksPerStripe) << ',' 
               << _stripeId << ",0,360," << _decMin << ',' << _decMax << '\n';                    
            return;
        }
        double const deltaRa = 360.0 / _numChunks;
        double raMin = 0.0;
        for (int i = 0; i < _numChunks; ++i)
        {
            // ensure last chunk has raMax of exactly 360 degrees. Note:
            // we assume inclusive min ra and exclusive max ra for chunks,
            double const raMax = (i == _numChunks - 1) ? 360.0 : (i + 1)*deltaRa;
            int chunkId = (_stripeId + stripesPerHemi)*maxChunksPerStripe + i;        
            os << chunkId << ',' << _stripeId << ',' <<
                  raMin    << ',' << raMax     << ',' <<
                  _decMin  << ',' << _decMax   << '\n';        
            raMin = raMax;
        }
    }

    void writeChunks(std::ostream & os, 
                     int const      maxChunksPerStripe,
                     int const      stripesPerHemi,
                     Box const &    box) const
    {
        if (_decMin > box._decMax || _decMax < box._decMin)
        {
            // no overlap between stripe and box
            return;
        }
        if (_numChunks <= 1)
        {
            os << ((_stripeId + stripesPerHemi)*maxChunksPerStripe) << '\n';                   
            return;
        }
        double const deltaRa = 360.0 / _numChunks;
        double raMin = 0.0;
        if (box._raMin < box._raMax)
        {
            for (int i = 0; i < _numChunks; ++i)
            {
                double const raMax = (i == _numChunks - 1) ? 360.0 : (i + 1)*deltaRa;
                if (raMin <= box._raMax && raMax >= box._raMin)
                {
                    os << ((_stripeId + stripesPerHemi)*maxChunksPerStripe + i) << '\n';
                }
                raMin = raMax;
            }
        }
        else
        {
            for (int i = 0; i < _numChunks; ++i)
            {
                double const raMax = (i == _numChunks - 1) ? 360.0 : (i + 1)*deltaRa;
                if (raMax >= box._raMin || raMin <= box._raMax)
                {
                    os << ((_stripeId + stripesPerHemi)*maxChunksPerStripe + i) << '\n';
                }
                raMin = raMax;
            }
        }
    }
    
    /*!
        Given a "minimum chunk width" (defined as the minimum allowable 
        distance between 2 points in non-adjacent chunks belonging to the 
        same stripe) and minimum/maximum stripe declination, returns the
        number of chunks to partition the stripe into.
     */
    static int chunksPerStripe(double const minWidth, 
                               double const decMin, 
                               double const decMax)
    {
        double maxAbsDec  = std::max(std::fabs(decMin), std::fabs(decMax));
        // 1 chunk only for stripes containing a pole 
        if (maxAbsDec > 89.99999)
        {
            return 1;
        }
        double cosWidth   = std::cos(gRadPerDeg * minWidth);
        double sinDec     = std::sin(gRadPerDeg * maxAbsDec);
        double cosDec     = std::cos(gRadPerDeg * maxAbsDec);
        cosWidth          = (cosWidth - sinDec*sinDec)/(cosDec*cosDec);
        if (cosWidth < 0)
        {
            return 1;
        }
        return static_cast<int>(std::floor(gTwoPi/std::acos(cosWidth)));
    }

    friend std::ostream & operator << (std::ostream & os, DecStripe const & s)
    {
        os << s._stripeId << ',' << s._numChunks << ',' <<
              s._decMin   << ',' << s._decMax    << '\n';
        return os;
    }
};


struct AscendingDecOrdering
{
     bool operator()(DecStripe const & first, DecStripe const & second)
     {
          return first.getDecMin() < second.getDecMin();
     }
};


template <class T>
bool fromString(T & t, char const * const s)
{
    std::istringstream iss(s);
    return !(iss >> t).fail();
}


int main(int argc, char ** argv)
{
using namespace std;    

    Box    box;
    double stripeHeight;
    bool   useBox = false;
    bool   useDecRange = false;   

    // read in arguments
    if (argc < 2 || argc > 7)
    {
        cerr << "Invalid argument list: "
                "the --help option displays usage instructions." << endl;
        return EXIT_FAILURE;
    }
    if (strncmp(argv[1], "--help", 6) == 0 && argc == 2)
    {
        printUsage(argv[0]);
        return EXIT_SUCCESS;
    }

    try
    {
        if (argc & 1 == 0)
        {
            // stripe height specified directly
            if (!fromString<double>(stripeHeight, argv[1]))
            {
                cerr << "Invalid argument: stripe_height is not a valid "
                        "floating point number." << endl;
                return EXIT_FAILURE;
            }
            if (stripeHeight < 600 || stripeHeight > 36000)
            {
                cerr << "Invalid argument: stripe_height must be between "
                        "600 and 36000 arcseconds" << endl;
                return EXIT_FAILURE;
            }
            // convert to degrees
            stripeHeight /= 3600;
        }
        else
        {
            // total # of zones and zones per stripe are given
            int numZones, zonesPerStripe;
            if (!fromString<int>(numZones, argv[1]) || 
                !fromString<int>(zonesPerStripe, argv[2]))
            {
                cerr << "Invalid arguments: num_zones and/or zones_per_stripe "
                        "are not valid integers." << endl;
                return EXIT_FAILURE;
            }
            if (numZones < 18 || numZones > 2592000)
            {
                cerr << "Invalid argument: num_zones must be between 18 and "
                        "2592000." << endl;
                return EXIT_FAILURE;
            }
            if (zonesPerStripe < 1)
            {
                cerr << "Invalid argument: zones_per_stripe must be "
                        "at least 1." << endl;
                return EXIT_FAILURE;
            }
            stripeHeight = (180.0 / numZones) * zonesPerStripe;
            if (stripeHeight < 0.1666666667 || stripeHeight > 10)
            {
                cerr << "Invalid arguments: zones_per_stripe must be adjusted to give "
                        "stripe_height between 10 arcminutes and 10 degrees" << endl;
                return EXIT_FAILURE;
            }
        }
        if (argc > 3)
        {
            int i = (argc > 5) ? argc - 4 : argc - 2;
            // A bounding box was passed in
            if (!fromString<double>(box._decMin, argv[i]) ||
                !fromString<double>(box._decMax, argv[i + 1]))
            {
                cerr << "Invalid argument: box boundaries must be specified "
                        "as floating point numbers." << endl;
                return EXIT_FAILURE;
            }
            if (box._decMin < -90.0 || box._decMin > 90.0 ||
                box._decMax < -90.0 || box._decMax > 90.0)
            {
                cerr << "Invalid argument: declination must be a "
                        "floating point number in the range [-90,90]." << endl;
                return EXIT_FAILURE;                    
            }                
            if (box._decMin >= box._decMax)
            {
                cerr << "Invalid argument: minimum declination must be "
                        "less than maximum declination." << endl;
                return EXIT_FAILURE;                    
            }
            if (argc > 5)
            {
                if (!fromString<double>(box._raMin,  argv[i + 2]) ||
                    !fromString<double>(box._raMax,  argv[i + 3]))
                {
                    cerr << "Invalid argument: box boundaries must be specified "
                            "as floating point numbers." << endl;
                    return EXIT_FAILURE;
                }
                if (box._raMin < 0.0 || box._raMin > 360.0 ||
                    box._raMax < 0.0 || box._raMax > 360.0)
                {
                    cerr << "Invalid argument: right ascension must be a "
                            "floating point number in the range [0,360]." << endl;
                    return EXIT_FAILURE;                    
                }
                useBox = true;
            }
            else
            {
                useDecRange = true;
            }
        }

        // Create a vector of stripes based on stripe height
        int const stripesPerHemi = static_cast<int>(ceil(90 / stripeHeight));
        int const numStripes = 2 * stripesPerHemi;
        double decMin = 0;
        vector<DecStripe> stripes;
        stripes.reserve(numStripes);
        for (int i = 0; i < stripesPerHemi; ++i)
        {
            double const decMax = (i == stripesPerHemi - 1) ? 90.0 : (i + 1)*stripeHeight;
            DecStripe s(decMin, decMax, stripeHeight, i);
            stripes.push_back(s);
            stripes.push_back(s.mirror());
            decMin = decMax;
        }
    
        // Sort stripes into ascending declination order and assign ids
        sort(stripes.begin(), stripes.end(), AscendingDecOrdering());
        
        int maxChunksPerStripe = DecStripe::chunksPerStripe(stripeHeight, 0.0, 0.0);

        if (useBox || useDecRange)
        {
            for (vector<DecStripe>::iterator itr = stripes.begin(); 
                 itr < stripes.end(); ++itr)
            {
                if (itr->getDecMin() > box._decMax || itr->getDecMax() < box._decMin)
                {
                    continue;
                }
                if (useDecRange)
                {
                    cout << itr->getId() << '\n';
                }
                else
                {
                    itr->writeChunks(cout, maxChunksPerStripe, stripesPerHemi, box);                    
                }
            }        
        }
        else
        {
            // Need to write stripe and chunk descriptions -
            // open CSV table files
            ofstream stripeFile, chunkFile;

            stripeFile.open("stripes.csv");
            chunkFile.open("chunks.csv");
    
            // Note: doubles that are converted to decimal strings with 17 or  
            // more sig. digits can be converted from strings back to binary 
            // form without change to the original value (assuming correctly- 
            // rounded string conversion and IEEE 754 doubles) 
            stripeFile.precision(17);
            chunkFile.precision(17);
    
            // output commented header lines for each table
            stripeFile << "# stripeId, numChunks, decMin, decMax\n"
                          "# int, int, double, double\n"
                          "# -, -, degrees, degrees\n";
                   
            chunkFile << "# chunkId, stripeId, raMin, raMax, decMin, decMax\n"
                         "# int, int, double, double, double, double\n"
                         "# -, -, degrees, degrees, degrees, degrees\n";

            // Write out stripes and chunks
            for (vector<DecStripe>::iterator itr = stripes.begin(); 
                 itr < stripes.end(); ++itr)
            {
                stripeFile << *itr;
                itr->writeChunks(chunkFile, maxChunksPerStripe, stripesPerHemi);
            }

            cout << "\nMax # of chunks per stripe: " 
                 << maxChunksPerStripe
                 << "\nStripes per hemisphere: "
                 << stripesPerHemi << endl;

            // All done
            stripeFile.close();
            chunkFile.close();
        }
    }
    catch (exception& e)
    {
        cerr << "Error: " << e.what() << endl;
        return EXIT_FAILURE;
    }
    return EXIT_SUCCESS;
}
