#! /usr/local/bin/bash
#
# ----------------------------------------------------------------
#
#   Script which performs setup steps for LSST zone based 
#   spatial partitioning tests. 
#
#
#   The following scripts need to have been run
#   before the this script can be run:
#
#   prepare.bash            - loads USNO B test data
#   prepare_stripes.bash    - creates stripe based partition tables
#
# ----------------------------------------------------------------

set -e

# Ensure working directory is the script directory
cur_dir=`pwd`
script_dir=`dirname $0`
if test "X" = "X$script_dir" ; then
    script_dir=cur_dir
else
    cd $script_dir
    script_dir=`pwd`
fi
echo "Running from script directory: $script_dir"

if test "X" = "X$TEST_DB" ; then
    echo "Please set the TEST_DB environment variable to the"
    echo "name of the MySQL database you want to use for testing"
    echo "and rerun the script"
    exit 1
fi

if test "X" = "X$IOSTAT_PARMS" ; then
    echo "Warning: IOSTAT_PARMS environment variable is undefined or empty."
    echo "         By default, iostat will be run as 'iostat -cdx 30'."
    IOSTAT_PARMS="-cdx 30"
fi

# Setup log file to record what's going on
LOGFILE=prepare_zones.log
rm -f $LOGFILE
touch $LOGFILE

# Load the stripe table names and their IDs
. stripe_vars.bash




# ----------------------------------------------------------------
# 1. Use myisamchk to sort rows
#
#    Note that for each table:
#        index 1 is on id (the primary key)
#        index 2 is on ra
#        index 3 is on (zoneId, ra)
#
# ----------------------------------------------------------------

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

         ------------------------------------------------
        | Sorting table records (clustering):
        | $TIMESTAMP ...
================================================================

END_OF_CAT

echo "WARNING: About to cluster indexes with myisamchk."
echo "While this is happening, *no one* should access mysql."

# flush memory before sorting
mysql $TEST_DB -e "FLUSH TABLES" >> $LOGFILE 2>&1

iostat $IOSTAT_PARMS >> $LOGFILE &
IOSTAT_PID="$(jobs -p %%)"

for table in $SKINNY_TABLES $FAT_TABLES
do
    ( cd /u2/mysql_data/$TEST_DB/; \
      time myisamchk --sort-records=3 --sort-index $table; \
      chgrp mysql $table.MYD $table.MYI; \
    ) >> $LOGFILE 2>&1
done

kill $IOSTAT_PID

TIMESTAMP=`date`
cat >> $LOGFILE <<END_OF_CAT

----------------------------------------------------------------
        | ... Done: $TIMESTAMP
         ----------------------------------------

END_OF_CAT

