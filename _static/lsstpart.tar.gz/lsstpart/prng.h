/*!
    \file       prng.h
    \brief      Functions for random number generation. 
 */

#ifndef PNRG_H
#define PNRG_H

namespace lsst {

/*! Initializes the random number generation functions. */
void initRandom();

/*! Returns a random number in the range [0,1). */
double random();

/*! Returns a random number in the range [0,1]. */
double random2();

/*! Generates normally distributed random numbers
    (with a standard deviation of 1). */
double normal();

/*! Performs a weighted coin toss: returns \em true with probability \a p
    and \em false with probability 1 - \a p. */
bool coinToss(double const p);

}

#endif
