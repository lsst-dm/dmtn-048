
# USNO-B schema, with various spatially derived quantities added
DROP TABLE IF EXISTS Object;

CREATE TABLE Object (       
    id           BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,  #8
    ra           DECIMAL(8,5) NOT NULL,                       #5
    decl         DECIMAL(8,5) NOT NULL,                       #5
    pm_ra        DECIMAL(8,5) NOT NULL,                       #5
    pm_raErr     SMALLINT NOT NULL,                           #2
    pm_decl      DECIMAL(8,5) NOT NULL,                       #5
    pm_decErr    SMALLINT NOT NULL,                           #2
    epoch        DECIMAL(6,1) NOT NULL,                       #4
    bMag         DECIMAL(5,3) NOT NULL,                       #3
    bErr         DECIMAL(5,3) NOT NULL,                       #3
    rMag         DECIMAL(5,3) NOT NULL,                       #3
    rErr         DECIMAL(5,3) NOT NULL,                       #3
    bMag2        DECIMAL(5,3) NOT NULL,                       #3
    bErr2        DECIMAL(5,3) NOT NULL,                       #3
    rMag2        DECIMAL(5,3) NOT NULL,                       #3
    rErr2        DECIMAL(5,3) NOT NULL,                       #3
    zoneId       INT NOT NULL DEFAULT 0,                      #4
    stripeId     SMALLINT NOT NULL DEFAULT 0,                 #2
    fineStripeId SMALLINT NOT NULL DEFAULT 0,                 #2
    chunkId      INT NOT NULL DEFAULT 0,                      #4
    fineChunkId  INT NOT NULL DEFAULT 0,                      #4
    x            DOUBLE NOT NULL DEFAULT 0.0,                 #8
    y            DOUBLE NOT NULL DEFAULT 0.0,                 #8
    z            DOUBLE NOT NULL DEFAULT 0.0,                 #8

    # Spatial index for extracting the fine chunk tables that
    # are involved in tests
    INDEX idx_spatial(fineStripeId, fineChunkId)
);

DROP TABLE IF EXISTS InMemoryFineChunkTemplate;

CREATE TABLE InMemoryFineChunkTemplate (       
    id           BIGINT NOT NULL PRIMARY KEY,
    ra           DECIMAL(8,5) NOT NULL,      
    decl         DECIMAL(8,5) NOT NULL,      
    pm_ra        DECIMAL(8,5) NOT NULL,      
    pm_raErr     SMALLINT NOT NULL,          
    pm_decl      DECIMAL(8,5) NOT NULL,      
    pm_decErr    SMALLINT NOT NULL,          
    epoch        DECIMAL(6,1) NOT NULL,      
    bMag         DECIMAL(5,3) NOT NULL,      
    bErr         DECIMAL(5,3) NOT NULL,      
    rMag         DECIMAL(5,3) NOT NULL,      
    rErr         DECIMAL(5,3) NOT NULL,      
    bMag2        DECIMAL(5,3) NOT NULL,      
    bErr2        DECIMAL(5,3) NOT NULL,      
    rMag2        DECIMAL(5,3) NOT NULL,      
    rErr2        DECIMAL(5,3) NOT NULL,      
    zoneId       INT NOT NULL DEFAULT 0,     
    stripeId     SMALLINT NOT NULL DEFAULT 0,
    fineStripeId SMALLINT NOT NULL DEFAULT 0,
    chunkId      INT NOT NULL DEFAULT 0,     
    fineChunkId  INT NOT NULL DEFAULT 0,     
    x            DOUBLE NOT NULL DEFAULT 0.0,
    y            DOUBLE NOT NULL DEFAULT 0.0,
    z            DOUBLE NOT NULL DEFAULT 0.0,

    INDEX idx_zone USING BTREE (zoneId)
) ENGINE = MEMORY;

DROP TABLE IF EXISTS ObjectStripes;
DROP TABLE IF EXISTS ObjectFineStripes;
DROP TABLE IF EXISTS MemStripes;

CREATE TABLE ObjectStripes (
    stripeId    SMALLINT NOT NULL PRIMARY KEY,
    numChunks   SMALLINT NOT NULL,
    decMin      DOUBLE NOT NULL,
    decMax      DOUBLE NOT NULL
);
CREATE TABLE ObjectFineStripes LIKE ObjectStripes;

CREATE TABLE MemStripes (
    stripeId    SMALLINT NOT NULL PRIMARY KEY,
    numChunks   SMALLINT NOT NULL
) ENGINE = MEMORY;

DROP TABLE IF EXISTS ObjectChunks;
DROP TABLE IF EXISTS ObjectFineChunks;
DROP TABLE IF EXISTS MemChunks;

CREATE TABLE ObjectChunks (
    chunkId     INT NOT NULL PRIMARY KEY,
    stripeId    SMALLINT NOT NULL,
    raMin       DOUBLE NOT NULL,
    raMax       DOUBLE NOT NULL,
    decMin      DOUBLE NOT NULL,
    decMax      DOUBLE NOT NULL
);
CREATE TABLE ObjectFineChunks LIKE ObjectChunks;

CREATE TABLE MemChunks (
    chunkId     INT NOT NULL,
    stripeId    SMALLINT NOT NULL,
    raMin       DOUBLE NOT NULL,
    raMax       DOUBLE NOT NULL,
    decMin      DOUBLE NOT NULL,
    decMax      DOUBLE NOT NULL,
    
    PRIMARY KEY USING BTREE (chunkId)
) ENGINE = MEMORY;

# For x-match
DROP TABLE IF EXISTS SecondaryZoneTemplate;

CREATE TABLE SecondaryZoneTemplate (
    ra   DOUBLE NOT NULL,
    decl DOUBLE NOT NULL,
    x    DOUBLE NOT NULL,
    y    DOUBLE NOT NULL,
    z    DOUBLE NOT NULL,
    id   BIGINT NOT NULL,
    zoneId  INT NOT NULL,

    INDEX idx_ra USING BTREE (ra)
) ENGINE = MEMORY;

# Maps zones to zones containing potential matches
DROP TABLE IF EXISTS ZoneZone;

CREATE TABLE ZoneZone (
    zoneId        INT    NOT NULL,
    matchZoneId   INT    NOT NULL,
    deltaRa       DOUBLE NOT NULL,
    
    # can also try KEY USING HASH (zoneId)
    PRIMARY KEY USING BTREE (zoneId, matchZoneId)
) ENGINE = MEMORY;

# Extracted/massaged from database schema 2.6.1,
# (LSST document 3044)
DROP TABLE IF EXISTS DIASource;

CREATE TABLE DIASource (
	id                   BIGINT        NOT NULL AUTO_INCREMENT PRIMARY KEY, # was diaSourceId
	ampExposureId        BIGINT        NOT NULL,
	filterId             TINYINT       NOT NULL,
	objectId             BIGINT        NULL,
	movingObjectId       BIGINT        NULL,
	procHistoryId        INTEGER       NOT NULL,
	scId                 INTEGER       NOT NULL,
	zoneId               INTEGER       NOT NULL, # was __zoneId_placeholder
	ra                   DOUBLE        NOT NULL,
	decl                 DOUBLE        NOT NULL,
	x                    DOUBLE        NOT NULL, # added for x-match
	y                    DOUBLE        NOT NULL, # added for x-match
	z                    DOUBLE        NOT NULL, # added for x-match
    stripeId             SMALLINT      NOT NULL, # added for spatial indexing
    fineStripeId         SMALLINT      NOT NULL, # added for spatial indexing
    chunkId              INT           NOT NULL, # added for spatial indexing
    fineChunkId          INT           NOT NULL, # added for spatial indexing
	raErr4detection      DECIMAL(7,5)  NOT NULL,
	decErr4detection     DECIMAL(7,5)  NOT NULL,
	raErr4wcs            DECIMAL(7,5)  NULL,
	decErr4wcs           DECIMAL(7,5)  NULL,
	xpos                 DECIMAL(7,2)  NOT NULL,
	ypos                 DECIMAL(7,2)  NOT NULL,
	xposErr              DECIMAL(4,2)  NOT NULL,
	yposErr              DECIMAL(4,2)  NOT NULL,
	cx                   FLOAT(0)      NOT NULL,
	cy                   FLOAT(0)      NOT NULL,
	cz                   FLOAT(0)      NOT NULL,
	taiMidPoint          DECIMAL(12,7) NOT NULL,
	taiRange             DECIMAL(12,7) NOT NULL,
	fwhmA                DECIMAL(4,2)  NOT NULL,
	fwhmB                DECIMAL(4,2)  NOT NULL,
	fwhmTheta            DECIMAL(4,1)  NOT NULL,
	flux                 DECIMAL(12,2) NOT NULL,
	fluxErr              DECIMAL(10,2) NOT NULL,
	psfMag               DECIMAL(7,3)  NOT NULL,
	psfMagErr            DECIMAL(6,3)  NOT NULL,
	apMag                DECIMAL(7,3)  NOT NULL,
	apMagErr             DECIMAL(6,3)  NOT NULL,
	apDia                FLOAT(0)      NULL,
	petroMag             FLOAT(0)      NULL,
	petroMagErr          FLOAT(0)      NULL,
	Ixx                  FLOAT(0)      NULL,
	IxxErr               FLOAT(0)      NULL,
	Iyy                  FLOAT(0)      NULL,
	IyyErr               FLOAT(0)      NULL,
	Ixy                  FLOAT(0)      NULL,
	IxyErr               FLOAT(0)      NULL,
	snr                  FLOAT(0)      NOT NULL,
	chi2                 FLOAT(0)      NOT NULL,
	flag4association     SMALLINT      NULL,
	flag4detection       SMALLINT      NULL,
	flag4wcs             SMALLINT      NULL,

	INDEX idx_spatial(fineStripeId, fineChunkId)
);

DROP TABLE IF EXISTS ObjectPhotoZ;

CREATE TABLE ObjectPhotoZ (
    id          BIGINT NOT NULL,
    redshift    FLOAT NOT NULL DEFAULT 0.0,
    redshiftErr FLOAT NOT NULL DEFAULT 0.0,
    probability TINYINT NOT NULL DEFAULT 100
);
