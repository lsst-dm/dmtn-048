#! /usr/local/bin/bash
#
# ----------------------------------------------------------------
#
#   Script which performs LSST fine chunk based 
#   spatial partitioning tests.
#
#   The following scripts need to have been run
#   before the test can proceed:
#
#   prepare.bash             - loads USNO B test data
#   prepare_fine_chunks.bash - creates fine chunk based partition tables
#
# ----------------------------------------------------------------

set -e

# Ensure working directory is the script directory
cur_dir=`pwd`
script_dir=`dirname $0`
if test "X" = "X$script_dir" ; then
    script_dir=cur_dir
else
    cd $script_dir
    script_dir=`pwd`
fi
echo "Running from script directory: $script_dir"

if test "X" = "X$TEST_DB" ; then
    echo "Please set the TEST_DB environment variable to the"
    echo "name of the MySQL database you want to use for testing"
    echo "and rerun the script"
    exit 1
fi

if test "X" = "X$IOSTAT_PARMS" ; then
    echo "Warning: IOSTAT_PARMS environment variable is undefined or empty."
    echo "         By default, iostat will be run as 'iostat -cdx 1'."
    IOSTAT_PARMS="-cdx 1"
fi

if test "X" = "X$MPSTAT_PARMS" ; then
    echo "Warning: MPSTAT_PARMS environment variable is undefined or empty."
    echo "         By default, mpstat will be run as 'mp -p 1'."
    MPSTAT_PARMS="-p 1"
fi


# Setup log file to record what's going on
LOGFILE=../logs/test_fine_chunks.log
rm -f $LOGFILE
touch $LOGFILE

# Load the test parameters
. test_regions.bash

# Set maximum size of a MySQL in-memory table 
mysql -e "SET GLOBAL max_heap_table_size=8589934592;"

# ------------------------------------------------
# Function that runs a single load test into a
# table with no indexes at all (sequential version).
#
# These tests are different from the coarse chunk
# version - each fine chunk gets its own in-memory table.
#
# NOTE: in this test implementation, in-memory table creation
# and loading is separated. Why is this OK? Because one can
# use empty pre-created in-memory tables (use enough empty tables,
# take stripeId and ra index within stripe modulo some size in each
# dimension -> in memory table name). So, instead of dropping them
# and creating them, TRUNCATE TABLE and reuse. A "partition-swap"
# update implementation still needs to create roughly 128 on-disk
# (MyISAM) tables. This can probably be charged to the prepare phase
# of a FOV...
#
# Parameters
# 1      Chunk table name prefix
# 2      An array of chunk table ids to load data into memory from
# 3      Template table name
# ------------------------------------------------
loadTest()
{
    mysql $TEST_DB -e "FLUSH TABLES;" >> $LOGFILE 2>&1

    SQL=""
    for id in $2 
    do
       FRAG="DROP TABLE IF EXISTS MemObj_$id;
             CREATE TABLE MemObj_$id LIKE $3;
             ALTER TABLE MemObj_$id DROP PRIMARY KEY;
             ALTER TABLE MemObj_$id DROP INDEX idx_zone;"
       SQL="$SQL $FRAG"
    done
    (time mysql $TEST_DB -e "$SQL" ) >> $LOGFILE 2>&1

    SQL=""
    for id in $2 
    do
       FRAG="INSERT INTO MemObj_$id SELECT * FROM $1$id;"
       SQL="$SQL $FRAG"
    done

    iostat $IOSTAT_PARMS >> $LOGFILE &
    IOSTAT_PID="$(jobs -p %%)"
    (time mysql $TEST_DB -e "$SQL") >> $LOGFILE 2>&1
    kill $IOSTAT_PID

    for id in $2
    do
        mysql $TEST_DB -s -e "SELECT count(*) FROM MemObj_$id" | sed s/count\(\*\)// >> $LOGFILE 2>&1
    done
}

# ------------------------------------------------
# Function that runs a single load test with
# indexes added before loading starts (sequential version)
#
# Parameters
# 1      Chunk table name prefix
# 2      An array of chunk table ids to load data into memory from
# 3      Template table name
# ------------------------------------------------
loadAndIndexTest()
{
    mysql $TEST_DB -e "FLUSH TABLES;" >> $LOGFILE 2>&1

    SQL=""
    for id in $2 
    do
       FRAG="DROP TABLE IF EXISTS MemObj_$id;
             CREATE TABLE MemObj_$id LIKE $3;"
       SQL="$SQL $FRAG"
    done
    (time mysql $TEST_DB -e "$SQL" ) >> $LOGFILE 2>&1

    SQL=""
    for id in $2 
    do
       FRAG="INSERT INTO MemObj_$id SELECT * FROM $1$id;"
       SQL="$SQL $FRAG"
    done

    iostat $IOSTAT_PARMS >> $LOGFILE &
    IOSTAT_PID="$(jobs -p %%)"
    (time mysql $TEST_DB -e "$SQL" ) >> $LOGFILE 2>&1
    kill $IOSTAT_PID

    for id in $2
    do
        mysql $TEST_DB -s -e "SELECT count(*) FROM MemObj_$id " | sed s/count\(\*\)// >> $LOGFILE 2>&1
    done
}

# ------------------------------------------------
# Function that runs a single load test and
# then generates indexes, sequential version
#
# Parameters
# 1      Chunk table name prefix
# 2      An array of chunk table ids to load data into memory from
# 3      Template table name
# ------------------------------------------------
loadThenIndexTest()
{
    mysql $TEST_DB -e "FLUSH TABLES;" >> $LOGFILE 2>&1

    SQL=""
    for id in $2 
    do
       FRAG="DROP TABLE IF EXISTS MemObj_$id;
             CREATE TABLE MemObj_$id LIKE $3;
             ALTER TABLE MemObj_$id DROP PRIMARY KEY;
             ALTER TABLE MemObj_$id DROP INDEX idx_zone;"
       SQL="$SQL $FRAG"
    done
    (time mysql $TEST_DB -e "$SQL" ) >> $LOGFILE 2>&1

    SQL=""
    for id in $2 
    do
       FRAG="INSERT INTO MemObj_$id SELECT * FROM $1$id;
             ALTER TABLE MemObj_$id ADD PRIMARY KEY (id);
             ALTER TABLE MemObj_$id ADD INDEX idx_zone USING BTREE (zoneId);"
       SQL="$SQL $FRAG"
    done

    iostat $IOSTAT_PARMS >> $LOGFILE &
    IOSTAT_PID="$(jobs -p %%)"
    (time mysql $TEST_DB -e "$SQL" ) >> $LOGFILE 2>&1
    kill $IOSTAT_PID

    for id in $2
    do
        mysql $TEST_DB -s -e "SELECT count(*) FROM MemObj_$id " | sed s/count\(\*\)// >> $LOGFILE 2>&1
    done
}

# ------------------------------------------------
# Sets up for x-match and update tests
#
# 1,2    The minimum,maximum dec of objects to load
# 3,4    The minimum,maximum ra of objects to load
# ------------------------------------------------
setupForWrites()
{
    CHUNKS=`chunkgen 10800 21 $1 $2 $3 $4`
    SQL="DROP TABLE IF EXISTS InMemoryDIASource;
         CREATE TABLE InMemoryDIASource LIKE DIASource;
         ALTER TABLE InMemoryDIASource ENGINE = MEMORY;
         ALTER TABLE InMemoryDIASource CHANGE COLUMN id id BIGINT NOT NULL;
         ALTER TABLE InMemoryDIASource DROP INDEX idx_spatial;
         ALTER TABLE InMemoryDIASource ADD INDEX idx_zone USING BTREE (zoneId);
         DROP TABLE IF EXISTS LooseMatch;
         CREATE TABLE LooseMatch (id1 bigint not null,
                                  id2 bigint not null) ENGINE = MEMORY;
         DROP TABLE IF EXISTS WideLooseMatch;
         CREATE TABLE WideLooseMatch LIKE InMemoryFineChunkTemplate;
         ALTER TABLE WideLooseMatch DROP PRIMARY KEY;
         ALTER TABLE WideLooseMatch DROP INDEX idx_zone;
         ALTER TABLE WideLooseMatch ADD COLUMN diaSourceId BIGINT NOT NULL;
         DROP TABLE IF EXISTS WideFatLooseMatch;
         CREATE TABLE WideFatLooseMatch LIKE InMemoryFineFatChunkTemplate;
         ALTER TABLE WideFatLooseMatch DROP PRIMARY KEY;
         ALTER TABLE WideFatLooseMatch DROP INDEX idx_zone;
         ALTER TABLE WideFatLooseMatch ADD COLUMN diaSourceId BIGINT NOT NULL;
         TRUNCATE TABLE MemChunks;
         INSERT INTO MemChunks SELECT * FROM ObjectFineChunks;
         TRUNCATE TABLE MemStripes;
         INSERT INTO MemStripes SELECT stripeId,numChunks FROM ObjectFineStripes;"

    mysql $TEST_DB -e "$SQL" >> $LOGFILE 2>&1
    
    cmp=$(echo "if($3 > $4) 1" | bc)
    if [[ $cmp -eq 1 ]]
    then
        WHERE_CLAUSE="((ra >= $3) or (ra < $4))"
    else
        WHERE_CLAUSE="ra >= $3 and ra < $4"
    fi
    WHERE_CLAUSE="WHERE decl >= $1 and decl < $2 and $WHERE_CLAUSE"

    SQL="INSERT INTO InMemoryDIASource SELECT * FROM DIASource $WHERE_CLAUSE;"
    (time mysql $TEST_DB -e "$SQL") >> $LOGFILE 2>&1
    (time mysql $TEST_DB -e "CALL sp_populateZoneZone(8.33e-4);") >> $LOGFILE 2>&1

    # chunk up the DIA Sources according to the same scheme as Objects
    for id in $CHUNKS
    do
        SQL="DROP TABLE IF EXISTS MemDIA_$id;
             CREATE TABLE MemDIA_$id LIKE InMemoryDIASource;
             INSERT INTO MemDIA_$id SELECT * FROM InMemoryDIASource WHERE fineChunkId = $id;"
        mysql $TEST_DB -e "$SQL" >> $LOGFILE 2>&1
    done
}

# ------------------------------------------------
# Performs a loose cross-match: (objectId, diaSourceId) pair version
#
# 1      list of stripe ids
# 2      ra minimum
# 3      ra maximum
# ------------------------------------------------
xmatch()
{
    echo "x-match, obj to dia:" >> $LOGFILE
    mysql $TEST_DB -e "TRUNCATE TABLE LooseMatch;"
    mpstat $MPSTAT_PARMS >> $LOGFILE &
    MPSTAT_PID="$(jobs -p %%)"
    for id in $1
    do
        (time mysql $TEST_DB -e "CALL sp_crossMatchStripe($id, 'MemObj_', 'MemDIA_', 'LooseMatch', 0.000833, 0, $2, $3);") >> $LOGFILE 2>&1
    done
    kill $MPSTAT_PID

    echo "x-match, dia to obj:" >> $LOGFILE
    mysql $TEST_DB -e "TRUNCATE TABLE LooseMatch;"
    mpstat $MPSTAT_PARMS >> $LOGFILE &
    MPSTAT_PID="$(jobs -p %%)"
    for id in $1
    do
        (time mysql $TEST_DB -e "CALL sp_crossMatchStripe($id, 'MemDIA_', 'MemObj_', 'LooseMatch', 0.000833, 0, $2, $3);") >> $LOGFILE 2>&1
    done
    kill $MPSTAT_PID
}

# ------------------------------------------------
# Performs a loose cross-match: (Object,diaSourceId) pair version
#
# 1      The name of the table to store matches in
# 2      list of stripe ids
# 3      ra minimum
# 4      ra maximum
# ------------------------------------------------
wxmatch()
{
    echo "wide x-match, obj to dia:" >> $LOGFILE
    mysql $TEST_DB -e "TRUNCATE TABLE $1;"
    mpstat $MPSTAT_PARMS >> $LOGFILE &
    MPSTAT_PID="$(jobs -p %%)"
    for id in $2
    do
        (time mysql $TEST_DB -e "CALL sp_crossMatchStripe($id, 'MemObj_', 'MemDIA_', '$1', 0.000833, 1, $3, $4);") >> $LOGFILE 2>&1
    done
    kill $MPSTAT_PID

    echo "wide x-match, dia to obj:" >> $LOGFILE
    mysql $TEST_DB -e "TRUNCATE TABLE $1;"
    mpstat $MPSTAT_PARMS >> $LOGFILE &
    MPSTAT_PID="$(jobs -p %%)"
    for id in $2
    do
        (time mysql $TEST_DB -e "CALL sp_crossMatchStripe($id, 'MemDIA_', 'MemObj_', '$1', 0.000833, -1, $3, $4);") >> $LOGFILE 2>&1
    done
    kill $MPSTAT_PID
}

# ------------------------------------------------
# Drops tables created during testing
# ------------------------------------------------
cleanup()
{
    for id in $1
    do
        mysql $TEST_DB -e "DROP TABLE IF EXISTS MemDIA_$id; DROP TABLE IF EXISTS MemObj_$id;" >> $LOGFILE 2>&1
    done
}




# ----------------------------------------------------------------
# 1. Get fine chunk ID lists for test regions and generate
#    test table names
# ----------------------------------------------------------------

HI_CHUNKS=`chunkgen 10800 21 $HI_DEC_MIN  $HI_DEC_MAX  $HI_RA_MIN  $HI_RA_MAX`
LO_CHUNKS=`chunkgen 10800 21 $LO_DEC_MIN  $LO_DEC_MAX  $LO_RA_MIN  $LO_RA_MAX`
AVG_CHUNKS=`chunkgen 10800 21 $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX`

HI_STRIPES=`chunkgen 10800 21 $HI_DEC_MIN  $HI_DEC_MAX`
LO_STRIPES=`chunkgen 10800 21 $LO_DEC_MIN  $LO_DEC_MAX`
AVG_STRIPES=`chunkgen 10800 21 $AVG_DEC_MIN $AVG_DEC_MAX`


# ----------------------------------------------------------------
# 2. Run load tests for the different FOVs. Each test runs twice
#    (so the effect of OS caching can be observed)
# ----------------------------------------------------------------

# Try to flush the OS filesystem cache
bustcache /u1/usno_data/USNOcat.csv 16384 

cat >> $LOGFILE <<END_OF_CAT

         ------------------------------------------
        | Running load test on high density FOV ...
================================================================
END_OF_CAT

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadTest "FcHi_1_" "$HI_CHUNKS" "InMemoryFineChunkTemplate"
loadTest "FcHi_1_" "$HI_CHUNKS" "InMemoryFineChunkTemplate"

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadTest "FcHiFat_1_" "$HI_CHUNKS" "InMemoryFineFatChunkTemplate"
loadTest "FcHiFat_1_" "$HI_CHUNKS" "InMemoryFineFatChunkTemplate"

cleanup "$HI_CHUNKS"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

cat >> $LOGFILE <<END_OF_CAT

         -----------------------------------------
        | Running load test on low density FOV ...
================================================================
END_OF_CAT

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadTest "FcLo_1_" "$LO_CHUNKS" "InMemoryFineChunkTemplate"
loadTest "FcLo_1_" "$LO_CHUNKS" "InMemoryFineChunkTemplate"

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadTest "FcLoFat_1_" "$LO_CHUNKS" "InMemoryFineFatChunkTemplate"
loadTest "FcLoFat_1_" "$LO_CHUNKS" "InMemoryFineFatChunkTemplate"

cleanup "$LO_CHUNKS"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

cat >> $LOGFILE <<END_OF_CAT

         ---------------------------------------------
        | Running load test on average density FOV ...
================================================================
END_OF_CAT

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadTest "FcAvg_1_" "$AVG_CHUNKS" "InMemoryFineChunkTemplate"
loadTest "FcAvg_1_" "$AVG_CHUNKS" "InMemoryFineChunkTemplate"

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadTest "FcAvgFat_1_" "$AVG_CHUNKS" "InMemoryFineFatChunkTemplate"
loadTest "FcAvgFat_1_" "$AVG_CHUNKS" "InMemoryFineFatChunkTemplate"

cleanup "$AVG_CHUNKS"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT




# ----------------------------------------------------------------
# 3. Run load-and-index test for the different FOVs. 
# ----------------------------------------------------------------

# Try to flush the OS filesystem cache
bustcache /u1/usno_data/USNOcat.csv 16384 

cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------------------
        | Running load-and-index test on high density FOV ...
================================================================
END_OF_CAT

setupForWrites $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadAndIndexTest "FcHi_1_" "$HI_CHUNKS" "InMemoryFineChunkTemplate"
xmatch "$HI_STRIPES" $HI_RA_MIN $HI_RA_MAX
loadAndIndexTest "FcHi_1_" "$HI_CHUNKS" "InMemoryFineChunkTemplate"
wxmatch "WideLooseMatch" "$HI_STRIPES" $HI_RA_MIN $HI_RA_MAX

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadAndIndexTest "FcHiFat_1_" "$HI_CHUNKS" "InMemoryFineFatChunkTemplate"
xmatch "$HI_STRIPES" $HI_RA_MIN $HI_RA_MAX
loadAndIndexTest "FcHiFat_1_" "$HI_CHUNKS" "InMemoryFineFatChunkTemplate"
wxmatch "WideFatLooseMatch" "$HI_STRIPES" $HI_RA_MIN $HI_RA_MAX

cleanup "$HI_CHUNKS"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

cat >> $LOGFILE <<END_OF_CAT

         ---------------------------------------------------
        | Running load-and-index test on low density FOV ...
================================================================
END_OF_CAT

setupForWrites $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadAndIndexTest "FcLo_1_" "$LO_CHUNKS" "InMemoryFineChunkTemplate"
xmatch "$LO_STRIPES" $LO_RA_MIN  $LO_RA_MAX
loadAndIndexTest "FcLo_1_" "$LO_CHUNKS" "InMemoryFineChunkTemplate"
wxmatch "WideLooseMatch" "$LO_STRIPES" $LO_RA_MIN  $LO_RA_MAX

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadAndIndexTest "FcLoFat_1_" "$LO_CHUNKS" "InMemoryFineFatChunkTemplate"
xmatch "$LO_STRIPES" $LO_RA_MIN  $LO_RA_MAX
loadAndIndexTest "FcLoFat_1_" "$LO_CHUNKS" "InMemoryFineFatChunkTemplate"
wxmatch "WideFatLooseMatch" "$LO_STRIPES" $LO_RA_MIN  $LO_RA_MAX

cleanup "$LO_CHUNKS"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

cat >> $LOGFILE <<END_OF_CAT

         -------------------------------------------------------
        | Running load-and-index test on average density FOV ...
================================================================
END_OF_CAT

setupForWrites $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadAndIndexTest "FcAvg_1_" "$AVG_CHUNKS" "InMemoryFineChunkTemplate"
xmatch "$AVG_STRIPES" $AVG_RA_MIN $AVG_RA_MAX
loadAndIndexTest "FcAvg_1_" "$AVG_CHUNKS" "InMemoryFineChunkTemplate"
wxmatch "WideLooseMatch" "$AVG_STRIPES" $AVG_RA_MIN $AVG_RA_MAX

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadAndIndexTest "FcAvgFat_1_" "$AVG_CHUNKS" "InMemoryFineFatChunkTemplate"
xmatch "$AVG_STRIPES" $AVG_RA_MIN $AVG_RA_MAX
loadAndIndexTest "FcAvgFat_1_" "$AVG_CHUNKS" "InMemoryFineFatChunkTemplate"
wxmatch "WideFatLooseMatch" "$AVG_STRIPES" $AVG_RA_MIN $AVG_RA_MAX

cleanup "$AVG_CHUNKS"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT





# ----------------------------------------------------------------
# 4. Run load-then-index test for the different FOVs. 
# ----------------------------------------------------------------

# Try to flush the OS filesystem cache
bustcache /u1/usno_data/USNOcat.csv 16384 

cat >> $LOGFILE <<END_OF_CAT

         -----------------------------------------------------
        | Running load-then-index test on high density FOV ...
================================================================
END_OF_CAT

setupForWrites $HI_DEC_MIN $HI_DEC_MAX $HI_RA_MIN $HI_RA_MAX

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadThenIndexTest "FcHi_1_" "$HI_CHUNKS" "InMemoryFineChunkTemplate"
xmatch "$HI_STRIPES" $HI_RA_MIN $HI_RA_MAX
loadThenIndexTest "FcHi_1_" "$HI_CHUNKS" "InMemoryFineChunkTemplate"
wxmatch "WideLooseMatch" "$HI_STRIPES" $HI_RA_MIN $HI_RA_MAX

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadThenIndexTest "FcHiFat_1_" "$HI_CHUNKS" "InMemoryFineFatChunkTemplate"
xmatch "$HI_STRIPES" $HI_RA_MIN $HI_RA_MAX
loadThenIndexTest "FcHiFat_1_" "$HI_CHUNKS" "InMemoryFineFatChunkTemplate"
wxmatch "WideFatLooseMatch" "$HI_STRIPES" $HI_RA_MIN $HI_RA_MAX

cleanup "$HI_CHUNKS"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

cat >> $LOGFILE <<END_OF_CAT

         ----------------------------------------------------
        | Running load-then-index test on low density FOV ...
================================================================
END_OF_CAT

setupForWrites $LO_DEC_MIN $LO_DEC_MAX $LO_RA_MIN $LO_RA_MAX

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadThenIndexTest "FcLo_1_" "$LO_CHUNKS" "InMemoryFineChunkTemplate"
xmatch "$LO_STRIPES" $LO_RA_MIN  $LO_RA_MAX
loadThenIndexTest "FcLo_1_" "$LO_CHUNKS" "InMemoryFineChunkTemplate"
wxmatch "WideLooseMatch" "$LO_STRIPES" $LO_RA_MIN  $LO_RA_MAX

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadThenIndexTest "FcLoFat_1_" "$LO_CHUNKS" "InMemoryFineFatChunkTemplate"
xmatch "$LO_STRIPES" $LO_RA_MIN  $LO_RA_MAX
loadThenIndexTest "FcLoFat_1_" "$LO_CHUNKS" "InMemoryFineFatChunkTemplate"
wxmatch "WideFatLooseMatch" "$LO_STRIPES" $LO_RA_MIN  $LO_RA_MAX

cleanup "$LO_CHUNKS"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

cat >> $LOGFILE <<END_OF_CAT

         --------------------------------------------------------
        | Running load-then-index test on average density FOV ...
=================================================================
END_OF_CAT

setupForWrites $AVG_DEC_MIN $AVG_DEC_MAX $AVG_RA_MIN $AVG_RA_MAX

/bin/echo " **** Skinny tables:\n\n" >> $LOGFILE
loadThenIndexTest "FcAvg_1_" "$AVG_CHUNKS" "InMemoryFineChunkTemplate"
xmatch "$AVG_STRIPES" $AVG_RA_MIN $AVG_RA_MAX
loadThenIndexTest "FcAvg_1_" "$AVG_CHUNKS" "InMemoryFineChunkTemplate"
wxmatch "WideLooseMatch" "$AVG_STRIPES" $AVG_RA_MIN $AVG_RA_MAX

/bin/echo "\n\n\n **** Fat tables:\n\n" >> $LOGFILE
loadThenIndexTest "FcAvgFat_1_" "$AVG_CHUNKS" "InMemoryFineFatChunkTemplate"
xmatch "$AVG_STRIPES" $AVG_RA_MIN $AVG_RA_MAX
loadThenIndexTest "FcAvgFat_1_" "$AVG_CHUNKS" "InMemoryFineFatChunkTemplate"
wxmatch "WideFatLooseMatch" "$AVG_STRIPES" $AVG_RA_MIN $AVG_RA_MAX

cleanup "$AVG_CHUNKS"

cat >> $LOGFILE <<END_OF_CAT
----------------------------------------------------------------
        | ... Done
         ----------------------------------------

END_OF_CAT

# cleanup
mysql $TEST_DB -e "DROP TABLE WideLooseMatch; DROP TABLE WideFatLooseMatch;"
